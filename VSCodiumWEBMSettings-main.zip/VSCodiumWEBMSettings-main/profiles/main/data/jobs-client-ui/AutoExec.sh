#!/bin/bash

### Github New Encryption System SSH Key Generation
### ssh-keygen -t ed25519 -C "your_email@example.com"
### ssh-keygen -t ed25519 -C "<GitEmailID/BitbucketEmailID>"
### ssh-keygen -t ed25519 -C "vivek@webmatrixcorp.com"
### ssh-keygen -t ed25519 -C "viveklucky1848@gmail.com"

### Composer Update instead of Install Packages in Git Repository:
### composer cc && COMPOSER_MEMORY_LIMIT=-1 composer update && composer du -o;
### composer cc && COMPOSER_MEMORY_LIMIT=-1 composer update && composer du -o;
### composer cc && COMPOSER_MEMORY_LIMIT=-1 composer update && composer du -o;

### Latest/Current RandallReilly Package Repository for Composer:
### https://repo.packagist.com/randallreilly
### https://repo.packagist.com/randallreilly
### https://repo.packagist.com/randallreilly

[ "`shopt -p expand_aliases`" == 'shopt -u expand_aliases' ] && shopt expand_aliases;
# $#  Number of arguments
# $*  All postional arguments (as a single word)
# $@  All postitional arguments (as separate strings)
# $1  First argument
# $_  Last argument of the previous command
if [ -z "$NODE_OPTIONS" ]; then
    read -n 1 -p "Set Node options (y/n)? " ch;
    # read -t 3 -n 1 -p "Set Node options (y/n)? " ch;
    [[ ! -z "$ch" && "$ch" = "y" ]] && export NODE_OPTIONS=--openssl-legacy-provider;
fi;
CWD=`PWD`;
Arg=("$@");
Prm=("$@");
ScrptArgs=("$@");
ScrptPrms=("$@");
RepoDir=${PWD##*/};
PrntDir=${PWD##*/};
RepoFldr=${PWD##*/};
PrntFldr=${PWD##*/};
alias extglob-on='shopt -s extglob;';
alias extglob-off='shopt -u extglob;';
HomeDirFilesFinal=(`ls -d $HOME/.??*`);
HomeFldrFilesFinal=(`ls -d $HOME/.??*`);
alias opn-hmbsh-fls='subl ~/.bash* ~/.profile';
alias vw-execs='"$SUBL" ~/.bash* *Exec.sh ~/.profile .git/config .git/info/exclude';
alias opn-execs='"$SUBL" ~/.bash* *Exec.sh ~/.profile .git/config .git/info/exclude';
alias edt-execs='"$SUBL" ~/.bash* *Exec.sh ~/.profile .git/config .git/info/exclude';
alias opn-all-execs='subl ~/.bash* *Exec.sh ~/.profile';
alias opn-auto-execs='subl ~/.bash* *Exec.sh ~/.profile';
alias opn-self-execs='subl ~/.bash* *Exec.sh ~/.profile';
alias cln-exec='cp Exec.sh SelfExec.sh && cp Exec.sh AutoExec.sh';
alias cpy-exec='cp Exec.sh SelfExec.sh && cp Exec.sh AutoExec.sh';
alias upd-exec='cp Exec.sh SelfExec.sh && cp Exec.sh AutoExec.sh';
alias sync-exec='cp Exec.sh SelfExec.sh && cp Exec.sh AutoExec.sh';
alias cln-exec2='cp Exec.sh SelfExec.sh && cp Exec.sh AutoExec.sh && cp SelfExec.sh AutoExec.sh ../jobs-platform/';
alias upd-exec2='cp Exec.sh SelfExec.sh && cp Exec.sh AutoExec.sh && cp SelfExec.sh AutoExec.sh ../jobs-platform/';
alias cpy-exec2='cp Exec.sh SelfExec.sh && cp Exec.sh AutoExec.sh && cp SelfExec.sh AutoExec.sh ../jobs-platform/';
alias sync-exec2='cp Exec.sh SelfExec.sh && cp Exec.sh AutoExec.sh && cp SelfExec.sh AutoExec.sh ../jobs-platform/';
RepoFldrTtl=`echo ${PWD##*/} | sed -e 's/-/ /g' -e 's/\b\(.\)/\u\1/g' | sed 's. ..g'`;
PrntFldrTtl=`echo ${PWD##*/} | sed -e 's/-/ /g' -e 's/\b\(.\)/\u\1/g' | sed 's. ..g'`;
RepoFldrLbl=`echo ${PWD##*/} | sed -e 's/-/ /g' -e 's/\b\(.\)/\u\1/g' | sed 's. ..g'`;
PrntFldrLbl=`echo ${PWD##*/} | sed -e 's/-/ /g' -e 's/\b\(.\)/\u\1/g' | sed 's. ..g'`;
alias clear-clipb='cat /dev/clipboard && cat /dev/null | clip.exe && cat /dev/clipboard';
alias purge-clipb='cat /dev/clipboard && cat /dev/null | clip.exe && cat /dev/clipboard';
alias clean-clipb='cat /dev/clipboard && cat /dev/null | clip.exe && cat /dev/clipboard';
alias empty-clipb='cat /dev/clipboard && cat /dev/null | clip.exe && cat /dev/clipboard';
alias rfrsh-jp-logs='rm -f ../jobs-platform/storage/logs/*.log';
alias opn-jp-logs='vi ../jobs-platform/storage/logs/*.log';
alias rm-ext="find . -name '*.$1' -type f -print -delete";
alias del-ext="find . -name '*.$1' -type f -print -delete";
alias prg-ext="find . -name '*.$1' -type f -print -delete";
alias rm-php-tmp="find . -name \*.php-tmp -type f -print -delete";
alias del-php-tmp="find . -name \*.php-tmp -type f -print -delete";
alias prg-php-tmp="find . -name \*.php-tmp -type f -print -delete";
alias rm-phpintl-fls="find . -name \*.php-tmp -type f -print -delete && rm -rf .phpintel";
alias prg-phpintl-fls="find . -name \*.php-tmp -type f -print -delete && rm -rf .phpintel";
alias del-phpintl-fls="find . -name \*.php-tmp -type f -print -delete && rm -rf .phpintel";
alias reset-cli-srvc="taskkill -f -t -im 'php*' -im ssh* && taskkill -f -t -im 'php*' -im ssh* && exit";
alias reset-cli-all-srvc="taskkill -f -t -im 'php*' -im ssh* -im 'node*' && taskkill -f -t -im 'php*' -im ssh* -im 'node*' && exit";
alias mk-kbf='file=./CodeSnips.kgbs && ( [ -e "$file" ] || touch "$file" ) && [ ! -w "$file" ] && echo cannot write to $file && exit 1';
alias crt-kbf='file=./CodeSnips.kgbs && ( [ -e "$file" ] || touch "$file" ) && [ ! -w "$file" ] && echo cannot write to $file && exit 1';
alias mk-kbf1='file=./CodeSnips.markdown && ( [ -e "$file" ] || touch "$file" ) && [ ! -w "$file" ] && echo cannot write to $file && exit 1; start CodeSnips.markdown';
alias crt-kbf1='file=./CodeSnips.markdown && ( [ -e "$file" ] || touch "$file" ) && [ ! -w "$file" ] && echo cannot write to $file && exit 1; start CodeSnips.markdown';
alias rst-gtgn='git restore **/*.gitignore' && alias updt-cdbs='git fetch --all -p && git pull && git pull origin && composer cc && composer du -o';
alias updt-cdbs0='!git fetch --all -p && git pull && git pull origin && composer cc && composer du -o';
alias gtrst-0='git restore storage/*.gitignore public/*.json && rm -rf .phpintel;';
alias gtrst-1='git restore storage/*.gitignore public/*.json && rm -rf .phpintel;';

# echo "" >> ~/.bash_profile
# echo 'if [ -f "$HOME/composer-autocomplete" ] ; then' >> ~/.bash_profile
# echo '    . $HOME/composer-autocomplete' >> ~/.bash_profile
# echo "fi" >> ~/.bash_profile

# echo "" >> ~/.bash_profile && \
# echo 'if [ -f "$HOME/composer-autocomplete" ] ; then' >> ~/.bash_profile && \
# echo '    . $HOME/composer-autocomplete' >> ~/.bash_profile && \
# echo "fi" >> ~/.bash_profile

function git-chckt-repo-brch-extnl {
    RepoName=$(basename "`git rev-parse --show-toplevel`");
    dir="$(basename $(pwd))" && dtstmp="$(date '+%F %T')" && read -p "Branch to checkout? " brch;
    if [ "$dir" == "jobs-client-ui" ]; then trgdr="../${dir}_$dtstmp/${brch}_$dtstmp"; fi;
    rm -rf "../${dir}_*";
    mkdir -p "$trgdr" && RepoUrl=`git config --get remote.origin.url` && cd "$trgdr";
    git clone $RepoUrl && cd "$RepoName" && git fetch --all -p && git checkout $brch && git pull && git pull origin;
}
function git-chckt-repo-brch-seprt {
    RepoName=$(basename "`git rev-parse --show-toplevel`");
    dir="$(basename $(pwd))" && dtstmp="$(date '+%F %T')" && read -p "Branch to checkout? " brch;
    if [ "$dir" == "jobs-client-ui" ]; then trgdr="../${dir}_$dtstmp/${brch}_$dtstmp"; fi;
    rm -rf "../${dir}_*";
    mkdir -p "$trgdr" && RepoUrl=`git config --get remote.origin.url` && cd "$trgdr";
    git clone $RepoUrl && cd "$RepoName" && git fetch --all -p && git checkout $brch && git pull && git pull origin;
}

function setNodeOpts() {
    if [ -z "$NODE_OPTIONS" ]; then
        read -n 1 -p "Set Node options (y/n)? " ch;
        # read -t 3 -n 1 -p "Set Node options (y/n)? " ch;
        [[ ! -z "$ch" && "$ch" = "y" ]] && export NODE_OPTIONS=--openssl-legacy-provider;
    fi;
}
function setNodeOptions() {
    if [ -z "$NODE_OPTIONS" ]; then
        read -n 1 -p "Set Node options (y/n)? " ch;
        # read -t 3 -n 1 -p "Set Node options (y/n)? " ch;
        [[ ! -z "$ch" && "$ch" = "y" ]] && export NODE_OPTIONS=--openssl-legacy-provider;
    fi;
}

laravel-artisan-models()(
    echo "Artisan model generator"
    echo "Created by Loupeznik (https://github.com/Loupeznik)"
    if [[ ! -e './artisan' ]]; then
        echo "[ERROR] Artisan not found in this directory, exiting"
        exit 1
    fi
    read -p "Enter model names separated by commas: " input
    if [ -z $input ]; then
        echo "[ERROR] No model names entered, exiting"
        exit 1
    fi
    echo "Enter switches to create additional classes, like controllers, no switch will be used if the field is left blank"
    echo "Available switches m - migration, s - seeder, f - factory, c - controller (-msfc)"
    read -p "Enter desired switches: " switches
    if [ -z $switches ]; then
        echo "[WARNING] No switch selected"
    else
        if [[ $switches != "-"* ]]; then
            switches="-$switches"
        fi
        if ( echo $switches | grep ! -Eq 'mscf' &> /dev/null ); then
            echo "[ERROR] The switch can contain only [mscf] characters"
            exit 1
        fi
    fi
    input=${input//[[:space:]]/}
    IFS=',' read -ra input_array <<< "$input"
    for i in "${input_array[@]}"
    do
        echo "[INFO] Creating model ${i}"
        php artisan make:model $i $switches
    done
)
laravel-artisan-new-models()(
    echo "Artisan model generator"
    echo "Created by Loupeznik (https://github.com/Loupeznik)"
    if [[ ! -e './artisan' ]]; then
        echo "[ERROR] Artisan not found in this directory, exiting"
        exit 1
    fi
    read -p "Enter model names separated by commas: " input
    if [ -z $input ]; then
        echo "[ERROR] No model names entered, exiting"
        exit 1
    fi
    echo "Enter switches to create additional classes, like controllers, no switch will be used if the field is left blank"
    echo "Available switches m - migration, s - seeder, f - factory, c - controller (-msfc)"
    read -p "Enter desired switches: " switches
    if [ -z $switches ]; then
        echo "[WARNING] No switch selected"
    else
        if [[ $switches != "-"* ]]; then
            switches="-$switches"
        fi
        if ( echo $switches | grep ! -Eq 'mscf' &> /dev/null ); then
            echo "[ERROR] The switch can contain only [mscf] characters"
            exit 1
        fi
    fi
    input=${input//[[:space:]]/}
    IFS=',' read -ra input_array <<< "$input"
    for i in "${input_array[@]}"
    do
        echo "[INFO] Creating model ${i}"
        php artisan make:model $i $switches
    done
)
laravel-artisan-make-models()(
    echo "Artisan model generator"
    echo "Created by Loupeznik (https://github.com/Loupeznik)"
    if [[ ! -e './artisan' ]]; then
        echo "[ERROR] Artisan not found in this directory, exiting"
        exit 1
    fi
    read -p "Enter model names separated by commas: " input
    if [ -z $input ]; then
        echo "[ERROR] No model names entered, exiting"
        exit 1
    fi
    echo "Enter switches to create additional classes, like controllers, no switch will be used if the field is left blank"
    echo "Available switches m - migration, s - seeder, f - factory, c - controller (-msfc)"
    read -p "Enter desired switches: " switches
    if [ -z $switches ]; then
        echo "[WARNING] No switch selected"
    else
        if [[ $switches != "-"* ]]; then
            switches="-$switches"
        fi
        if ( echo $switches | grep ! -Eq 'mscf' &> /dev/null ); then
            echo "[ERROR] The switch can contain only [mscf] characters"
            exit 1
        fi
    fi
    input=${input//[[:space:]]/}
    IFS=',' read -ra input_array <<< "$input"
    for i in "${input_array[@]}"
    do
        echo "[INFO] Creating model ${i}"
        php artisan make:model $i $switches
    done
)
laravel-artisan-create-models()(
    echo "Artisan model generator"
    echo "Created by Loupeznik (https://github.com/Loupeznik)"
    if [[ ! -e './artisan' ]]; then
        echo "[ERROR] Artisan not found in this directory, exiting"
        exit 1
    fi
    read -p "Enter model names separated by commas: " input
    if [ -z $input ]; then
        echo "[ERROR] No model names entered, exiting"
        exit 1
    fi
    echo "Enter switches to create additional classes, like controllers, no switch will be used if the field is left blank"
    echo "Available switches m - migration, s - seeder, f - factory, c - controller (-msfc)"
    read -p "Enter desired switches: " switches
    if [ -z $switches ]; then
        echo "[WARNING] No switch selected"
    else
        if [[ $switches != "-"* ]]; then
            switches="-$switches"
        fi
        if ( echo $switches | grep ! -Eq 'mscf' &> /dev/null ); then
            echo "[ERROR] The switch can contain only [mscf] characters"
            exit 1
        fi
    fi
    input=${input//[[:space:]]/}
    IFS=',' read -ra input_array <<< "$input"
    for i in "${input_array[@]}"
    do
        echo "[INFO] Creating model ${i}"
        php artisan make:model $i $switches
    done
)
laravel-artisan-spawn-models()(
    echo "Artisan model generator"
    echo "Created by Loupeznik (https://github.com/Loupeznik)"
    if [[ ! -e './artisan' ]]; then
        echo "[ERROR] Artisan not found in this directory, exiting"
        exit 1
    fi
    read -p "Enter model names separated by commas: " input
    if [ -z $input ]; then
        echo "[ERROR] No model names entered, exiting"
        exit 1
    fi
    echo "Enter switches to create additional classes, like controllers, no switch will be used if the field is left blank"
    echo "Available switches m - migration, s - seeder, f - factory, c - controller (-msfc)"
    read -p "Enter desired switches: " switches
    if [ -z $switches ]; then
        echo "[WARNING] No switch selected"
    else
        if [[ $switches != "-"* ]]; then
            switches="-$switches"
        fi
        if ( echo $switches | grep ! -Eq 'mscf' &> /dev/null ); then
            echo "[ERROR] The switch can contain only [mscf] characters"
            exit 1
        fi
    fi
    input=${input//[[:space:]]/}
    IFS=',' read -ra input_array <<< "$input"
    for i in "${input_array[@]}"
    do
        echo "[INFO] Creating model ${i}"
        php artisan make:model $i $switches
    done
)

git-branch-archive()(
    Drv=`cygpath $AltDrv` && BkpDstPth="$Drv/WbmLrvlLrngs/BranchCloneBackups" && rm -f *.tgz;
    brch=`git symbolic-ref --short HEAD` && cbrch=`git symbolic-ref --short HEAD`
    read -ep 'Branch to archive?(CurrentBranch):' -i $brch brch
    git checkout -f $brch && git fetch --all -p && git pull && git pull origin && git checkout -f $cbrch
    git -C ./ archive --format tgz -19 -o ./$brch-`date +%Y-%m-%dT%H%M`.tgz $brch
    rm -f $BkpDstPth/$brch*.tgz && install -D ./*.tgz -m 664 -t $BkpDstPth && rm -f *.tgz
)
git-branch-compress()(
    Drv=`cygpath $AltDrv` && BkpDstPth="$Drv/WbmLrvlLrngs/BranchCloneBackups" && rm -f *.tgz;
    brch=`git symbolic-ref --short HEAD` && cbrch=`git symbolic-ref --short HEAD`
    read -ep 'Branch to archive?(CurrentBranch):' -i $brch brch
    git checkout -f $brch && git fetch --all -p && git pull && git pull origin && git checkout -f $cbrch
    git -C ./ archive --format tgz -19 -o ./$brch-`date +%Y-%m-%dT%H%M`.tgz $brch
    rm -f $BkpDstPth/$brch*.tgz && install -D ./*.tgz -m 664 -t $BkpDstPth && rm -f *.tgz
)
git-any-branch-archive()(
    Drv=`cygpath $AltDrv` && BkpDstPth="$Drv/WbmLrvlLrngs/BranchCloneBackups" && rm -f *.tgz;
    brch=`git symbolic-ref --short HEAD` && cbrch=`git symbolic-ref --short HEAD`
    read -ep 'Branch to archive?(CurrentBranch):' -i $brch brch
    git checkout -f $brch && git fetch --all -p && git pull && git pull origin && git checkout -f $cbrch
    git -C ./ archive --format tgz -19 -o ./$brch-`date +%Y-%m-%dT%H%M`.tgz $brch
    rm -f $BkpDstPth/$brch*.tgz && install -D ./*.tgz -m 664 -t $BkpDstPth && rm -f *.tgz
)
git-any-branch-compress()(
    Drv=`cygpath $AltDrv` && BkpDstPth="$Drv/WbmLrvlLrngs/BranchCloneBackups" && rm -f *.tgz;
    brch=`git symbolic-ref --short HEAD` && cbrch=`git symbolic-ref --short HEAD`
    read -ep 'Branch to archive?(CurrentBranch):' -i $brch brch
    git checkout -f $brch && git fetch --all -p && git pull && git pull origin && git checkout -f $cbrch
    git -C ./ archive --format tgz -19 -o ./$brch-`date +%Y-%m-%dT%H%M`.tgz $brch
    rm -f $BkpDstPth/$brch*.tgz && install -D ./*.tgz -m 664 -t $BkpDstPth && rm -f *.tgz
)
git-slctd-branch-archive()(
    Drv=`cygpath $AltDrv` && BkpDstPth="$Drv/WbmLrvlLrngs/BranchCloneBackups" && rm -f *.tgz;
    brch=`git symbolic-ref --short HEAD` && cbrch=`git symbolic-ref --short HEAD`
    read -ep 'Branch to archive?(CurrentBranch):' -i $brch brch
    git checkout -f $brch && git fetch --all -p && git pull && git pull origin && git checkout -f $cbrch
    git -C ./ archive --format tgz -19 -o ./$brch-`date +%Y-%m-%dT%H%M`.tgz $brch
    rm -f $BkpDstPth/$brch*.tgz && install -D ./*.tgz -m 664 -t $BkpDstPth && rm -f *.tgz
)
git-slctd-branch-compress()(
    Drv=`cygpath $AltDrv` && BkpDstPth="$Drv/WbmLrvlLrngs/BranchCloneBackups" && rm -f *.tgz;
    brch=`git symbolic-ref --short HEAD` && cbrch=`git symbolic-ref --short HEAD`
    read -ep 'Branch to archive?(CurrentBranch):' -i $brch brch
    git checkout -f $brch && git fetch --all -p && git pull && git pull origin && git checkout -f $cbrch
    git -C ./ archive --format tgz -19 -o ./$brch-`date +%Y-%m-%dT%H%M`.tgz $brch
    rm -f $BkpDstPth/$brch*.tgz && install -D ./*.tgz -m 664 -t $BkpDstPth && rm -f *.tgz
)
git-spcfc-branch-archive()(
    Drv=`cygpath $AltDrv` && BkpDstPth="$Drv/WbmLrvlLrngs/BranchCloneBackups" && rm -f *.tgz;
    brch=`git symbolic-ref --short HEAD` && cbrch=`git symbolic-ref --short HEAD`
    read -ep 'Branch to archive?(CurrentBranch):' -i $brch brch
    git checkout -f $brch && git fetch --all -p && git pull && git pull origin && git checkout -f $cbrch
    git -C ./ archive --format tgz -19 -o ./$brch-`date +%Y-%m-%dT%H%M`.tgz $brch
    rm -f $BkpDstPth/$brch*.tgz && install -D ./*.tgz -m 664 -t $BkpDstPth && rm -f *.tgz
)
git-spcfc-branch-compress()(
    Drv=`cygpath $AltDrv` && BkpDstPth="$Drv/WbmLrvlLrngs/BranchCloneBackups" && rm -f *.tgz;
    brch=`git symbolic-ref --short HEAD` && cbrch=`git symbolic-ref --short HEAD`
    read -ep 'Branch to archive?(CurrentBranch):' -i $brch brch
    git checkout -f $brch && git fetch --all -p && git pull && git pull origin && git checkout -f $cbrch
    git -C ./ archive --format tgz -19 -o ./$brch-`date +%Y-%m-%dT%H%M`.tgz $brch
    rm -f $BkpDstPth/$brch*.tgz && install -D ./*.tgz -m 664 -t $BkpDstPth && rm -f *.tgz
)
git-prtclr-branch-archive()(
    Drv=`cygpath $AltDrv` && BkpDstPth="$Drv/WbmLrvlLrngs/BranchCloneBackups" && rm -f *.tgz;
    brch=`git symbolic-ref --short HEAD` && cbrch=`git symbolic-ref --short HEAD`
    read -ep 'Branch to archive?(CurrentBranch):' -i $brch brch
    git checkout -f $brch && git fetch --all -p && git pull && git pull origin && git checkout -f $cbrch
    git -C ./ archive --format tgz -19 -o ./$brch-`date +%Y-%m-%dT%H%M`.tgz $brch
    rm -f $BkpDstPth/$brch*.tgz && install -D ./*.tgz -m 664 -t $BkpDstPth && rm -f *.tgz
)
git-prtclr-branch-compress()(
    Drv=`cygpath $AltDrv` && BkpDstPth="$Drv/WbmLrvlLrngs/BranchCloneBackups" && rm -f *.tgz;
    brch=`git symbolic-ref --short HEAD` && cbrch=`git symbolic-ref --short HEAD`
    read -ep 'Branch to archive?(CurrentBranch):' -i $brch brch
    git checkout -f $brch && git fetch --all -p && git pull && git pull origin && git checkout -f $cbrch
    git -C ./ archive --format tgz -19 -o ./$brch-`date +%Y-%m-%dT%H%M`.tgz $brch
    rm -f $BkpDstPth/$brch*.tgz && install -D ./*.tgz -m 664 -t $BkpDstPth && rm -f *.tgz
)
git-branch-archive-smart()(
    mst=master && dvlp=develop;
    Drv=`cygpath $AltDrv` && BkpDstPth="$Drv/WbmLrvlLrngs/BranchCloneBackups";
    brch=`git symbolic-ref --short HEAD` && cbrch=`git symbolic-ref --short HEAD`
    read -ep 'Branch to archive?(CurrentBranch):' -i $brch brch;
    git fetch --all -p && git fetch origin $mst:$mst && git fetch origin $dvlp:$dvlp;
    git fetch --all -p && git fetch origin $brch:$brch;
    git -C ./ archive --format tgz -19 -o ./$brch-`date +%Y-%m-%dT%H%M`.tgz $brch
    rm -f $BkpDstPth/$brch*.tgz && install -D ./*.tgz -m 664 -t $BkpDstPth && rm -f *.tgz
)
git-branch-compress-smart()(
    mst=master && dvlp=develop;
    Drv=`cygpath $AltDrv` && BkpDstPth="$Drv/WbmLrvlLrngs/BranchCloneBackups";
    brch=`git symbolic-ref --short HEAD` && cbrch=`git symbolic-ref --short HEAD`
    read -ep 'Branch to archive?(CurrentBranch):' -i $brch brch;
    git fetch --all -p && git fetch origin $mst:$mst && git fetch origin $dvlp:$dvlp;
    git fetch --all -p && git fetch origin $brch:$brch;
    git -C ./ archive --format tgz -19 -o ./$brch-`date +%Y-%m-%dT%H%M`.tgz $brch
    rm -f $BkpDstPth/$brch*.tgz && install -D ./*.tgz -m 664 -t $BkpDstPth && rm -f *.tgz
)

git-curr-branch-archive()(
    curr_brch=`git symbolic-ref --short HEAD`
    git -C ./ archive --format tgz -19 -o ./$curr_brch-`date +%Y-%m-%dT%H%M`.tgz $curr_brch
    install -D ./*.tgz -m 664 -t /e/WbmLrvlLrngs/BranchCloneBackups && rm -f *.tgz
    # rm -f $BkpDstPth/$brch*.tgz && install -D ./*.tgz -m 664 -t $BkpDstPth && rm -f *.tgz
)
git-curr-branch-compress()(
    curr_brch=`git symbolic-ref --short HEAD`
    git -C ./ archive --format tgz -19 -o ./$curr_brch-`date +%Y-%m-%dT%H%M`.tgz $curr_brch
    install -D ./*.tgz -m 664 -t /e/WbmLrvlLrngs/BranchCloneBackups && rm -f *.tgz
    # rm -f $BkpDstPth/$brch*.tgz && install -D ./*.tgz -m 664 -t $BkpDstPth && rm -f *.tgz
)

git-onetime-auth-setup() {
    [ "`is-git`" != true ] && { echo Invalid Git Repo && return 1; }
    read -ep 'UserName(VIVEK SHAH):' -i 'VIVEK SHAH' UserName;
    read -ep 'EmailId(vivek@webmatrixcorp.com):' -i 'vivek@webmatrixcorp.com' EmailId;
    echo $UserName ':' $EmailId;
    git config user.name "$UserName" && git config user.email "$EmailId";
    git config --global user.name "$UserName" && git config --global user.email "$EmailId";
}
git-onetime-auth-setup-1() {
    [ "`is-git`" != true ] && { echo Invalid Git Repo && return 1; }
    read -ep 'UserName(VIVEK SHAH):' -i 'VIVEK SHAH' UserName;
    read -ep 'EmailId(vivek@webmatrixcorp.com):' -i 'vivek@webmatrixcorp.com' EmailId;
    echo $UserName ':' $EmailId;
    git config user.name "$UserName" && git config user.email "$EmailId";
    git config --global user.name "$UserName" && git config --global user.email "$EmailId";
}
git-onetime-prfl-setup() {
    [ "`is-git`" != true ] && { echo Invalid Git Repo && return 1; }
    read -ep 'UserName(VIVEK SHAH):' -i 'VIVEK SHAH' UserName;
    read -ep 'EmailId(vivek@webmatrixcorp.com):' -i 'vivek@webmatrixcorp.com' EmailId;
    echo $UserName ':' $EmailId;
    git config user.name "$UserName" && git config user.email "$EmailId";
    git config --global user.name "$UserName" && git config --global user.email "$EmailId";
}
git-onetime-accnt-setup() {
    [ "`is-git`" != true ] && { echo Invalid Git Repo && return 1; }
    read -ep 'UserName(VIVEK SHAH):' -i 'VIVEK SHAH' UserName;
    read -ep 'EmailId(vivek@webmatrixcorp.com):' -i 'vivek@webmatrixcorp.com' EmailId;
    echo $UserName ':' $EmailId;
    git config user.name "$UserName" && git config user.email "$EmailId";
    git config --global user.name "$UserName" && git config --global user.email "$EmailId";
}
git-onetime-creds-setup() {
    [ "`is-git`" != true ] && { echo Invalid Git Repo && return 1; }
    read -ep 'UserName(VIVEK SHAH):' -i 'VIVEK SHAH' UserName;
    read -ep 'EmailId(vivek@webmatrixcorp.com):' -i 'vivek@webmatrixcorp.com' EmailId;
    echo $UserName ':' $EmailId;
    git config user.name "$UserName" && git config user.email "$EmailId";
    git config --global user.name "$UserName" && git config --global user.email "$EmailId";
}

# ^[\t ]*<param name="logic" .*\n$
opn-home-bash-files() { subl ~/{.profile,.bashrc,.bash_profile}; }
CLP() { rm -f ~/.bash_history && history -wc && history -cw && reset && clear; } && trap 'CLP' SIGTERM;
# trap 'rm -f ~/.bash_history && history -wc && history -cw && reset && exit' SIGINT && stty -echo && read input;
# trap "rm -f ~/.bash_history && history -wc && history -cw && reset" SIGINT && stty -echo && read input;
trapClean() {
    # cleanup() { rm ~/.bash_history && history -wc && history -cw && reset; } && trap cleanup SIGTERM;
    cleanup() { rm -f ~/.bash_history && history -wc && history -cw && reset; } && trap cleanup SIGTERM;
    read -p 'Ctrl+C now and return code is default for SIGTERM.';
}
bash-cmdlog() { rm -f ~/.bash_history && history -wc && history -cw && reset && clear; }
bash-history() { rm -f ~/.bash_history && history -wc && history -cw && reset && clear; }
# trap bash-cmdlog INT SIGINT SIGTERM;

test-func1() { IFS=$'\n' && echo "$*"; IFS=, && echo "$*"; }
test-func2() { IFS=$'\n' && echo "$@"; IFS=, && echo "$@"; }
test-func-dolstr() { IFS=$'\n' && echo "$*"; IFS=, && echo "$*"; }
test-func-dolatr() { IFS=$'\n' && echo "$@"; IFS=, && echo "$@"; }

ps-list(){
    # ps > ps.out.tmp && columns='WINPID';
    # IFS=$'\n' && echo "$*"
    fields="$*" && fields2="$@" && fieldsCsv=`IFS=, && echo "$*"`;
    ps > ps.out.tmp && columns="$*" && columns2="$@";
    awk -v cols="${columns}" '
BEGIN  { n=split(cols,arr,",")            # parse list of column names
         for (i=1;i<=n;i++)
             headers[arr[i]]              # convert to associative array
       }
FNR==1 { for (i=1;i<=NF;i++)              # for each field (aka column) header ...
             if ($i in headers)           # if it is in headers[] then ...
                fields[i]                 # keep track of the associated field #
       }
       { pfx=""
         for (i=1;i<=NF;i++) {            # for each input field # ...
             if (i in fields) {           # if it is in fields[] then ...
                printf "%s%s", pfx, $i    # print the field (aka column)
                pfx=OFS
             }
         }
         printf "\n"                      # terminate the line
       }
' ps.out.tmp && rm -f ps.out.tmp;
}

ps-list-orig(){
    rm -f ps.out.tmp && ps > ps.out.tmp && columns='COMMAND';
    awk -v cols="${columns}" '
BEGIN  { n=split(cols,arr,",")            # parse list of column names
         for (i=1;i<=n;i++)
             headers[arr[i]]              # convert to associative array
       }
FNR==1 { for (i=1;i<=NF;i++)              # for each field (aka column) header ...
             if ($i in headers)           # if it is in headers[] then ...
                fields[i]                 # keep track of the associated field #
       }
       { pfx=""
         for (i=1;i<=NF;i++) {            # for each input field # ...
             if (i in fields) {           # if it is in fields[] then ...
                printf "%s%s", pfx, $i    # print the field (aka column)
                pfx=OFS
             }
         }
         printf "\n"                      # terminate the line
       }
' ps.out.tmp | column -t && rm -f ps.out.tmp;
}
# HomeDirFilesList=`ls -ap $HOME | grep -v / | egrep '^\.'`;
# HomeFldrFilesList=`ls -ap $HOME | grep -v / | egrep '^\.'`;
# HomeDirFiles=`${HomeDirFilesList[@]/#/${HOME}\/}`;
# HomeFldrFiles=`${HomeDirFilesList[@]/#/$HOME\/}`;
# HomeDirDotFiles=`${HomeDirFilesList[@]/#/$HOME\/}`;
# HomeFldrDotFiles=`${HomeDirFilesList[@]/#/$HOME\/}`;
# alias opn-fls-ptrn="_(){ subl `find . -name \*.$1`; }; _";
# alias opn-fls-ptrn2="_(){ subl `find . -name \*$1`; }; _";
alias vue-ver='npm list vue | grep '\''vue@'\'' | sed '\''s/[^0-9.]*//g'\'' | sort -u';
alias vuejs-ver='npm list vue | grep '\''vue@'\'' | sed '\''s/[^0-9.]*//g'\'' | sort -u';
alias vue--version='npm list vue | grep '\''vue@'\'' | sed '\''s/[^0-9.]*//g'\'' | sort -u';
alias vuejs--version='npm list vue | grep '\''vue@'\'' | sed '\''s/[^0-9.]*//g'\'' | sort -u';
alias opn-vue-fls-ptrn='_(){ subl `find . -path ./node_modules -prune -o -name "*$1*vue" | tr "\n" " "`; }; _';
alias opn-vue-fls-ptrn2='_(){ subl `find . -path ./node_modules -prune -o -name "*$1*vue" | tr '\''\n'\'' '\'' '\''`; }; _';
alias opn-fls-ptrn='_(){ subl `find . -path ./node_modules -prune -o -name "*$1*$2" | tr "\n" " "`; }; _';
alias opn-fls-ptrn2='_(){ subl `find . -path ./node_modules -prune -o -name "*$1*$2" | tr '\''\n'\'' '\'' '\''`; }; _';
# alias run-mgrtn-ptrn="php artisan migrate `php.exe artisan migrate:status | grep 'No' | cut -d'|' -f3 | tr -d' ' | grep '$1'`";

alias ignr-mxmnfst='git rm --cached public/mix-manifest.json && echo '\''/public/mix-manifest.json'\''>>.gitignore';
alias ignr-mxmnfst1='git rm --cached public/mix-manifest.json && echo '\''/public/mix-manifest.json'\''>>.gitignore';
alias ignr-mxmnfst2='git rm --cached public/mix-manifest.json && echo '\''/public/mix-manifest.json'\''>>.gitignore';
ignr-mxmnfstv1() {
    git rm --cached public/mix-manifest.json && read -p "Commit Message: " CommitMsg;
    grep -qxF '/public/mix-manifest.json' .gitignore || echo '/public/mix-manifest.json'>>.gitignore;
    git add -u && git commit -am "$CommitMsg" && git push origin HEAD;
}
ignr-mxmnfstv1() {
    git rm --cached public/mix-manifest.json && read -p "Commit Message: " CommitMsg;
    grep -qxF '/public/mix-manifest.json' .gitignore || echo '/public/mix-manifest.json'>>.gitignore;
    git add -u && git commit -am "$CommitMsg" && git push origin HEAD;
}
ignr-mxmnfstv2() {
    git rm --cached public/mix-manifest.json && read -p "Commit Message: " CommitMsg;
    grep -qxF '/public/mix-manifest.json' .gitignore || echo '/public/mix-manifest.json'>>.gitignore;
    git add -u && git commit -am "$CommitMsg" && git push origin HEAD;
}
ignr-mxmnfst-fnl() {
    git rm --cached public/mix-manifest.json && read -p "Commit Message: " CommitMsg;
    grep -qxF '/public/mix-manifest.json' .gitignore || echo '/public/mix-manifest.json'>>.gitignore;
    git add -u && git commit -am "$CommitMsg" && git push origin HEAD;
}
ignr-mxmnfst-rdy() {
    git rm --cached public/mix-manifest.json && read -p "Commit Message: " CommitMsg;
    grep -qxF '/public/mix-manifest.json' .gitignore || echo '/public/mix-manifest.json'>>.gitignore;
    git add -u && git commit -am "$CommitMsg" && git push origin HEAD;
}
npm-rmv-pkgs-ptrn() {
    # npm un --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm rm --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm unlink --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm remove --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm uninstall --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm un --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm rm --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm unlink --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm remove --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm uninstall --save;
}
npm-del-pkgs-ptrn() {
    # npm un --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm rm --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm unlink --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm remove --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm uninstall --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm un --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm rm --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm unlink --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm remove --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm uninstall --save;
}
npm-prg-pkgs-ptrn() {
    # npm un --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm rm --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm unlink --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm remove --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm uninstall --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm un --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm rm --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm unlink --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm remove --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm uninstall --save;
}
npm-unst-pkgs-ptrn() {
    # npm un --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm rm --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm unlink --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm remove --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    # npm uninstall --save `npm list | egrep '*fortawesome*' | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | tr '/\n' ' '`;
    npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm un --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm rm --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm unlink --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm remove --save;
    # npm list | egrep "*$1*" | sed 's/^[┬├│─└ ]*//g' | cut -d@ -f1-2 | xargs npm uninstall --save;
}

lvrl-mgrt-ptrn-mtch() {
    mgrtn_name="php.exe artisan migrate:status | grep 'No' | cut -d '|' -f3 | tr -d ' ' | grep '$1'";
    mgrtn_name=`eval $mgrtn_name`;
    mgrtn_file="./database/migrations/$mgrtn_name.php";
    php artisan migrate --path="$mgrtn_file";
}
lvrl-rlbck-ptrn-mtch() {
    mgrtn_name="php.exe artisan migrate:status | grep 'Yes' | cut -d '|' -f3 | tr -d ' ' | grep '$1'";
    mgrtn_name=`eval $mgrtn_name`;
    mgrtn_file="./database/migrations/$mgrtn_name.php";
    php artisan migrate:rollback --path="$mgrtn_file";
}
lvrl-rfrsh-ptrn-mtch() {
    mgrtn_name="php.exe artisan migrate:status | grep 'No' | cut -d '|' -f3 | tr -d ' ' | grep '$1'";
    mgrtn_name=`eval $mgrtn_name`;
    mgrtn_file="./database/migrations/$mgrtn_name.php";
    php artisan migrate:refresh --path="$mgrtn_file";
}
lvrl-mgrt-ptrn-mtch-fnl() {
    mgrtn_name="php.exe artisan migrate:status | grep 'No' | cut -d '|' -f3 | tr -d ' ' | grep '$1'";
    mgrtn_name=`eval $mgrtn_name`;
    mgrtn_file="./database/migrations/$mgrtn_name.php";
    php artisan migrate --path="$mgrtn_file";
}
lvrl-rlbck-ptrn-mtch-fnl() {
    mgrtn_name="php.exe artisan migrate:status | grep 'No' | cut -d '|' -f3 | tr -d ' ' | grep '$1'";
    mgrtn_name=`eval $mgrtn_name`;
    mgrtn_file="./database/migrations/$mgrtn_name.php";
    php artisan migrate:rollback --path="$mgrtn_file";
}
lvrl-rfrsh-ptrn-mtch-fnl() {
    mgrtn_name="php.exe artisan migrate:status | grep 'No' | cut -d '|' -f3 | tr -d ' ' | grep '$1'";
    mgrtn_name=`eval $mgrtn_name`;
    mgrtn_file="./database/migrations/$mgrtn_name.php";
    php artisan migrate:refresh --path="$mgrtn_file";
}

function DelAllBkpFls {
    read -r -p 'Delete Backups? [Y/n] ' opt && opt=${opt,,} && [[ "$opt" =~ ^(yes|y)$ ]] && {
        BackupDir='/e/WbmLrvlLrngs/ShellScriptBackups' && shopt -s extglob;
        BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && shopt -s extglob;
        rm -rf $BackupDir/**/..?* $BackupDir/**/*.!\(tgz\) $BackupDir/**/.[!.]*;
        rm -rf $BackupDir/**/..?* $BackupDir/**/*.!\(tgz\) $BackupDir/**/.[!.]*;
        find $BackupDir -type d -empty -print && find $BackupDir -type d -empty -delete;
    }
}
function DelAllBkpFlsDone {
    read -r -p 'Delete Backups? [Y/n] ' opt && opt=${opt,,} && [[ "$opt" =~ ^(yes|y)$ ]] && {
        BackupDir='/e/WbmLrvlLrngs/ShellScriptBackups' && shopt -s extglob;
        BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && shopt -s extglob;
        rm -rf $BackupDir/**/..?* $BackupDir/**/*.!\(tgz\) $BackupDir/**/.[!.]*;
        rm -rf $BackupDir/**/..?* $BackupDir/**/*.!\(tgz\) $BackupDir/**/.[!.]*;
        find $BackupDir -type d -empty -print && find $BackupDir -type d -empty -delete;
    }
}
function DelAllBkpFlsFinal {
    read -r -p 'Delete Backups? [Y/n] ' opt && opt=${opt,,} && [[ "$opt" =~ ^(yes|y)$ ]] && {
        BackupDir='/e/WbmLrvlLrngs/ShellScriptBackups' && shopt -s extglob;
        BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && shopt -s extglob;
        rm -rf $BackupDir/**/..?* $BackupDir/**/*.!\(tgz\) $BackupDir/**/.[!.]*;
        rm -rf $BackupDir/**/..?* $BackupDir/**/*.!\(tgz\) $BackupDir/**/.[!.]*;
        find $BackupDir -type d -empty -print && find $BackupDir -type d -empty -delete;
    }
}
function DelAllBkpFlsUsable {
    read -r -p 'Delete Backups? [Y/n] ' opt && opt=${opt,,} && [[ "$opt" =~ ^(yes|y)$ ]] && {
        BackupDir='/e/WbmLrvlLrngs/ShellScriptBackups' && shopt -s extglob;
        BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && shopt -s extglob;
        rm -rf $BackupDir/**/..?* $BackupDir/**/*.!\(tgz\) $BackupDir/**/.[!.]*;
        rm -rf $BackupDir/**/..?* $BackupDir/**/*.!\(tgz\) $BackupDir/**/.[!.]*;
        find $BackupDir -type d -empty -print && find $BackupDir -type d -empty -delete;
    }
}

bak-this() {
    AltPrtn=`cygpath $AltDrv`;
    GitBashUsrBin=`cygpath "$PROGRAMFILES"`"/Git/usr/bin";
    find ./../ -name "Jobs*Exec-*.sh" -type f -print -delete;
    # BackupDir='/e/WbmLrvlLrngs/ShellScriptBackups' && rm -rf $BackupDir/${PWD##*/};
    # BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && rm -rf $BackupDir/*;
    BackupDir="${AltPrtn}/WbmLrvlLrngs/ShellScriptBackups" && rm -rf $BackupDir/${PWD##*/};
    BackupPath="${AltPrtn}/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && rm -rf $BackupDir/*;
    rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && rm -f .env-*;
    # mkdir -p $BackupDir/home-user && cp -r ~/.[^.]* $BackupDir/home-user;
    mkdir -p $BackupDir/home-user && cp ~/{.bashrc,.profile,.bash_profile} $BackupDir/home-user;
    cp ~/{.lesshst,.minttyrc,.gitconfig,composer-autocomplete} $BackupDir/home-user;
    cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    cp Exec.sh SelfExec.sh && cp Exec.sh AutoExec.sh;
    cp ./*Exec*.sh ../jobs-platform && cp ./*Exec*sh ../jobs-platform;
    install -D ./*Exec*.sh -m 664 -t $BackupPath && install -D ./*.markdown -m 664 -t $BackupPath;
    tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env >/dev/null;
    rm -f $BackupPath/.env-* && install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    install -D ./All.credentials -m 664 -t $BackupPath;
    mkdir -p $BackupPath/git && cp -r ./.[^.]* $BackupPath && rm -rf $BackupPath/.git && cp -r .git/config .git/info/exclude $BackupPath/git;
    cd ../jobs-platform && rm -rf $BackupPath/.git && mkdir -p $BackupPath/.git && cp -r .git/config .git/info/exclude $BackupPath/.git;
    mkdir -p $BackupDir/GitBashTools && cp "$GitBashUsrBin/{wget.exe,rsync.exe,cc*.exe}" $BackupDir/GitBashTools;
    find $BackupDir -printf "%P\n" | env GZIP=-9 tar -czvf $BackupDir'/ShellScriptBackups.tgz' --no-recursion -C $BackupDir -T -;
    ccrypt $BackupDir'/ShellScriptBackups.tgz' && start '' $BackupDir;
    cp Exec.sh SelfExec.sh && cp Exec.sh AutoExec.sh;
    cp ./*Exec*.sh ../jobs-platform && cp ./*Exec*sh ../jobs-platform;
};
bak-this0() {
    AltPrtn=`cygpath $AltDrv`; SubDirPath="WbmLrvlLrngs/ShellScriptBackups0";
    GitBashUsrBin=`cygpath "$PROGRAMFILES"`"/Git/usr/bin"; FileName="ShellScriptBackups0.tgz";
    find ./../ -name "Jobs*Exec-*.sh" -type f -print -delete;
    BackupDir="${AltPrtn}/${SubDirPath}" && rm -rf $BackupDir/${PWD##*/};
    BackupPath="${AltPrtn}/${SubDirPath}/${PWD##*/}" && rm -rf $BackupDir/*;
    BackupHome="$BackupDir/$USERNAME" && mkdir -p $BackupHome;
    rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && rm -f .env-*;
    mkdir -p $BackupHome && cp ~/{.bashrc,.profile,.bash_profile} $BackupHome;
    cp ~/{.lesshst,.minttyrc,.gitconfig,composer-autocomplete} $BackupHome;
    cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    cp Exec.sh SelfExec.sh && cp Exec.sh AutoExec.sh && cp -ra ~/.ssh/. $BackupHome/.ssh;
    cp ./*Exec*.sh ../jobs-platform && cp ./*Exec*sh ../jobs-platform;
    install -D ./*Exec*.sh -m 664 -t $BackupPath && install -D ./*.markdown -m 664 -t $BackupPath;
    tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env >/dev/null;
    rm -f $BackupPath/.env-* && install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    install -D ./All.credentials -m 664 -t $BackupPath;
    mkdir -p $BackupPath/git && cp -r ./.[^.]* $BackupPath && rm -rf $BackupPath/.git && cp -r .git/config .git/info/exclude $BackupPath/git;
    cd ../jobs-platform && rm -rf $BackupPath/.git && mkdir -p $BackupPath/.git && cp -r .git/config .git/info/exclude $BackupPath/.git;
    mkdir -p $BackupDir/GitBashTools && cp "$GitBashUsrBin/{wget.exe,rsync.exe,cc*.exe}" $BackupDir/GitBashTools;
    find $BackupDir -printf "%P\n" | env GZIP=-9 tar -czvf $BackupDir"/${FileName}" --no-recursion -C $BackupDir -T -;
    ccrypt $BackupDir"/${FileName}" && start '' $BackupDir;
    cp Exec.sh SelfExec.sh && cp Exec.sh AutoExec.sh;
    cp ./*Exec*.sh ../jobs-platform && cp ./*Exec*sh ../jobs-platform;
};
bak-this-now() {
    AltPrtn=`cygpath $AltDrv`;
    GitBashUsrBin=`cygpath "$PROGRAMFILES"`"/Git/usr/bin";
    find ./../ -name "Jobs*Exec-*.sh" -type f -print -delete;
    # BackupDir='/e/WbmLrvlLrngs/ShellScriptBackups' && rm -rf $BackupDir/${PWD##*/};
    # BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && rm -rf $BackupDir/*;
    BackupDir="${AltPrtn}/WbmLrvlLrngs/ShellScriptBackups" && rm -rf $BackupDir/${PWD##*/};
    BackupPath="${AltPrtn}/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && rm -rf $BackupDir/*;
    rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && rm -f .env-*;
    # mkdir -p $BackupDir/home-user && cp -r ~/.[^.]* $BackupDir/home-user;
    mkdir -p $BackupDir/home-user && cp ~/{.bashrc,.profile,.bash_profile} $BackupDir/home-user;
    cp ~/{.lesshst,.minttyrc,.gitconfig} $BackupDir/home-user;
    cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    install -D ./*Exec*.sh -m 664 -t $BackupPath && install -D ./*.markdown -m 664 -t $BackupPath;
    tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env >/dev/null;
    rm -f $BackupPath/.env-* && install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    install -D ./All.credentials -m 664 -t $BackupPath;
    mkdir -p $BackupPath/git && cp -r ./.[^.]* $BackupPath && rm -rf $BackupPath/.git && cp -r .git/config .git/info/exclude $BackupPath/git;
    mkdir -p $BackupDir/GitBashTools && cp "$GitBashUsrBin/{wget.exe,rsync.exe,cc*.exe}" $BackupDir/GitBashTools;
    find $BackupDir -printf "%P\n" | env GZIP=-9 tar -czvf $BackupDir'/ShellScriptBackups.tgz' --no-recursion -C $BackupDir -T -;
    ccrypt $BackupDir'/ShellScriptBackups.tgz' && start '' $BackupDir;
};
bak-this-final() {
    AltPrtn=`cygpath $AltDrv`;
    GitBashUsrBin=`cygpath "$PROGRAMFILES"`"/Git/usr/bin";
    find ./../ -name "Jobs*Exec-*.sh" -type f -print -delete;
    # BackupDir='/e/WbmLrvlLrngs/ShellScriptBackups' && rm -rf $BackupDir/${PWD##*/};
    # BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && rm -rf $BackupDir/*;
    BackupDir="${AltPrtn}/WbmLrvlLrngs/ShellScriptBackups" && rm -rf $BackupDir/${PWD##*/};
    BackupPath="${AltPrtn}/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && rm -rf $BackupDir/*;
    rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && rm -f .env-*;
    # mkdir -p $BackupDir/home-user && cp -r ~/.[^.]* $BackupDir/home-user;
    mkdir -p $BackupDir/home-user && cp ~/{.bashrc,.profile,.bash_profile} $BackupDir/home-user;
    cp ~/{.lesshst,.minttyrc,.gitconfig} $BackupDir/home-user;
    cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    install -D ./*Exec*.sh -m 664 -t $BackupPath && install -D ./*.markdown -m 664 -t $BackupPath;
    tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env >/dev/null;
    rm -f $BackupPath/.env-* && install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    install -D ./All.credentials -m 664 -t $BackupPath;
    mkdir -p $BackupPath/git && cp -r ./.[^.]* $BackupPath && rm -rf $BackupPath/.git && cp -r .git/config .git/info/exclude $BackupPath/git;
    mkdir -p $BackupDir/GitBashTools && cp "$GitBashUsrBin/{wget.exe,rsync.exe,cc*.exe}" $BackupDir/GitBashTools;
    find $BackupDir -printf "%P\n" | env GZIP=-9 tar -czvf $BackupDir'/ShellScriptBackups.tgz' --no-recursion -C $BackupDir -T -;
    ccrypt $BackupDir'/ShellScriptBackups.tgz' && start '' $BackupDir;
};
bak-this-current() {
    AltPrtn=`cygpath $AltDrv`;
    GitBashUsrBin=`cygpath "$PROGRAMFILES"`"/Git/usr/bin";
    find ./../ -name "Jobs*Exec-*.sh" -type f -print -delete;
    # BackupDir='/e/WbmLrvlLrngs/ShellScriptBackups' && rm -rf $BackupDir/${PWD##*/};
    # BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && rm -rf $BackupDir/*;
    BackupDir="${AltPrtn}/WbmLrvlLrngs/ShellScriptBackups" && rm -rf $BackupDir/${PWD##*/};
    BackupPath="${AltPrtn}/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && rm -rf $BackupDir/*;
    rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && rm -f .env-*;
    # mkdir -p $BackupDir/home-user && cp -r ~/.[^.]* $BackupDir/home-user;
    mkdir -p $BackupDir/home-user && cp ~/{.bashrc,.profile,.bash_profile} $BackupDir/home-user;
    cp ~/{.lesshst,.minttyrc,.gitconfig} $BackupDir/home-user;
    cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    install -D ./*Exec*.sh -m 664 -t $BackupPath && install -D ./*.markdown -m 664 -t $BackupPath;
    tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env >/dev/null;
    rm -f $BackupPath/.env-* && install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    install -D ./All.credentials -m 664 -t $BackupPath;
    mkdir -p $BackupPath/git && cp -r ./.[^.]* $BackupPath && rm -rf $BackupPath/.git && cp -r .git/config .git/info/exclude $BackupPath/git;
    mkdir -p $BackupDir/GitBashTools && cp "$GitBashUsrBin/{wget.exe,rsync.exe,cc*.exe}" $BackupDir/GitBashTools;
    find $BackupDir -printf "%P\n" | env GZIP=-9 tar -czvf $BackupDir'/ShellScriptBackups.tgz' --no-recursion -C $BackupDir -T -;
    ccrypt $BackupDir'/ShellScriptBackups.tgz' && start '' $BackupDir;
};
bak-this-present() {
    AltPrtn=`cygpath $AltDrv`;
    GitBashUsrBin=`cygpath "$PROGRAMFILES"`"/Git/usr/bin";
    find ./../ -name "Jobs*Exec-*.sh" -type f -print -delete;
    # BackupDir='/e/WbmLrvlLrngs/ShellScriptBackups' && rm -rf $BackupDir/${PWD##*/};
    # BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && rm -rf $BackupDir/*;
    BackupDir="${AltPrtn}/WbmLrvlLrngs/ShellScriptBackups" && rm -rf $BackupDir/${PWD##*/};
    BackupPath="${AltPrtn}/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && rm -rf $BackupDir/*;
    rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && rm -f .env-*;
    # mkdir -p $BackupDir/home-user && cp -r ~/.[^.]* $BackupDir/home-user;
    mkdir -p $BackupDir/home-user && cp ~/{.bashrc,.profile,.bash_profile} $BackupDir/home-user;
    cp ~/{.lesshst,.minttyrc,.gitconfig} $BackupDir/home-user;
    cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    install -D ./*Exec*.sh -m 664 -t $BackupPath && install -D ./*.markdown -m 664 -t $BackupPath;
    tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env >/dev/null;
    rm -f $BackupPath/.env-* && install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    install -D ./All.credentials -m 664 -t $BackupPath;
    mkdir -p $BackupPath/git && cp -r ./.[^.]* $BackupPath && rm -rf $BackupPath/.git && cp -r .git/config .git/info/exclude $BackupPath/git;
    mkdir -p $BackupDir/GitBashTools && cp "$GitBashUsrBin/{wget.exe,rsync.exe,cc*.exe}" $BackupDir/GitBashTools;
    find $BackupDir -printf "%P\n" | env GZIP=-9 tar -czvf $BackupDir'/ShellScriptBackups.tgz' --no-recursion -C $BackupDir -T -;
    ccrypt $BackupDir'/ShellScriptBackups.tgz' && start '' $BackupDir;
};
bak_this() {
    AltPrtn=`cygpath $AltDrv`;
    GitBashUsrBin=`cygpath "$PROGRAMFILES"`"/Git/usr/bin";
    find ./../ -name "Jobs*Exec-*.sh" -type f -print -delete;
    # BackupDir='/e/WbmLrvlLrngs/ShellScriptBackups' && rm -rf $BackupDir/${PWD##*/};
    # BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && rm -rf $BackupDir/*;
    BackupDir="${AltPrtn}/WbmLrvlLrngs/ShellScriptBackups" && rm -rf $BackupDir/${PWD##*/};
    BackupPath="${AltPrtn}/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}" && rm -rf $BackupDir/*;
    rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && rm -f .env-*;
    # mkdir -p $BackupDir/home-user && cp -r ~/.[^.]* $BackupDir/home-user;
    mkdir -p $BackupDir/home-user && cp ~/{.bashrc,.profile,.bash_profile} $BackupDir/home-user;
    cp ~/{.lesshst,.minttyrc,.gitconfig} $BackupDir/home-user;
    cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    install -D ./*Exec*.sh -m 664 -t $BackupPath && install -D ./*.markdown -m 664 -t $BackupPath;
    tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env >/dev/null;
    rm -f $BackupPath/.env-* && install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    install -D ./All.credentials -m 664 -t $BackupPath;
    mkdir -p $BackupPath/git && cp -r ./.[^.]* $BackupPath && rm -rf $BackupPath/.git && cp -r .git/config .git/info/exclude $BackupPath/git;
    mkdir -p $BackupDir/GitBashTools && cp "$GitBashUsrBin/{wget.exe,rsync.exe,cc*.exe}" $BackupDir/GitBashTools;
    find $BackupDir -printf "%P\n" | env GZIP=-9 tar -czvf $BackupDir'/ShellScriptBackups.tgz' --no-recursion -C $BackupDir -T -;
    ccrypt $BackupDir'/ShellScriptBackups.tgz' && start '' $BackupDir;
} && export -f bak_this;
bakthis() {
    AltPrtn=`cygpath $AltDrv`;
    BackupDir='/e/WbmLrvlLrngs/ShellScriptBackups' && rm -rf $BackupDir/${PWD##*/};
    BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}";
    find ./../ -name "Jobs*Exec-*.sh" -type f -print -delete;
    rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && rm -f .env-*;
    # rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && find $BackupDir -type d -empty -print;
    # find . -type d -empty -delete;
    # rm -f $RepoFldrTtl.Exec*.sh $BackupPath/$RepoFldrTtl.Exec*.sh;
    cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh"
    # cp ./*Exec*.sh /e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}
    # install -D ./*Exec*.sh /e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}
    install -D ./*Exec*.sh -m 664 -t $BackupPath;
    tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env >/dev/null
    # install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    rm -f $BackupPath/.env-* && install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    install -D ./*Exec*.sh -m 664 -t $BackupPath && install -D ./*.markdown -m 664 -t $BackupPath;
    # cp ~/{.profile,.bashrc,.bash_profile} $BackupPath && cp .git/{config, info/exclude} $BackupPath;
    # cp ~/{.profile,.bashrc,.bash_profile} $BackupPath && cp -rT .git $BackupPath;
    mkdir -p $BackupPath/git && cp -r ./.[^.]* $BackupPath && rm -rf $BackupPath/.git && cp -r .git/config .git/info/exclude $BackupPath/git;
    find $BackupDir -printf "%P\n" | env GZIP=-9 tar -czvf $BackupDir'/ShellScriptBackups.tgz' --no-recursion -C $BackupDir -T -;
    DelAllBkpFls; start '' $BackupDir;
} && export -f bakthis;
bakthisfinal() {
    AltPrtn=`cygpath $AltDrv`;
    BackupDir='/e/WbmLrvlLrngs/ShellScriptBackups';
    BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}";
    find ./../ -name "Jobs*Exec-*.sh" -type f -print -delete;
    rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && rm -f .env-*;
    # rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && find $BackupDir -type d -empty -print;
    # find . -type d -empty -delete;
    # rm -f $RepoFldrTtl.Exec*.sh $BackupPath/$RepoFldrTtl.Exec*.sh;
    cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh"
    install -D ./*Exec*.sh -m 664 -t $BackupPath;
    tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env >/dev/null
    # install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    rm -f $BackupPath/.env-* && install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    install -D ./All.credentials -m 664 -t $BackupPath;
    cp ~/{.profile,.bashrc,.bash_profile} $BackupPath && cp .git/{config, info/exclude} $BackupPath;
    find $BackupDir -printf "%P\n" | env GZIP=-9 tar -czvf $BackupDir'/ShellScriptBackups.tgz' --no-recursion -C $BackupDir -T -;
    DelAllBkpFls; start '' $BackupDir;
} && export -f bakthisfinal;
bakthis1() {
    AltPrtn=`cygpath $AltDrv`;
    BackupDir='/e/WbmLrvlLrngs/ShellScriptBackups';
    BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}";
    find ./../ -name "Jobs*Exec-*.sh" -type f -print -delete;
    rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && rm -f .env-*;
    # rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && find $BackupDir -type d -empty -print;
    # find . -type d -empty -delete;
    # rm -f $RepoFldrTtl.Exec*.sh $BackupPath/$RepoFldrTtl.Exec*.sh;
    cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    sleep 2 && cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    sleep 2 && cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    install -D ./*Exec*.sh -m 664 -t $BackupPath;
    tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env >/dev/null
    # install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    rm -f $BackupPath/.env-* && install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    install -D ./All.credentials -m 664 -t $BackupPath;
    cp ~/{.profile,.bashrc,.bash_profile} $BackupPath && cp .git/{config, info/exclude} $BackupPath;
    find $BackupDir -printf "%P\n" | env GZIP=-9 tar -czvf $BackupDir'/ShellScriptBackups.tgz' --no-recursion -C $BackupDir -T -;
    DelAllBkpFls; start '' $BackupDir;
} && export -f bakthis1;
bakthis-v1() {
    AltPrtn=`cygpath $AltDrv`;
    BackupDir='/e/WbmLrvlLrngs/ShellScriptBackups';
    BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}";
    find ./../ -name "Jobs*Exec-*.sh" -type f -print -delete;
    rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && rm -f .env-*;
    # rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && find $BackupDir -type d -empty -print;
    # find . -type d -empty -delete;
    # rm -f $RepoFldrTtl.Exec*.sh $BackupPath/$RepoFldrTtl.Exec*.sh;
    cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    sleep 2 && cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    sleep 2 && cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    install -D ./*Exec*.sh -m 664 -t $BackupPath;
    tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env >/dev/null
    # install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
     rm -f $BackupPath/.env-* && install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
     install -D ./All.credentials -m 664 -t $BackupPath;
    cp ~/{.profile,.bashrc,.bash_profile} $BackupPath && cp .git/{config, info/exclude} $BackupPath;
    find $BackupDir -printf "%P\n" | env GZIP=-9 tar -czvf $BackupDir'/ShellScriptBackups.tgz' --no-recursion -C $BackupDir -T -;
    DelAllBkpFls; start '' $BackupDir;
} && export -f bakthis-v1;
bakthisfinalv1() {
    AltPrtn=`cygpath $AltDrv`;
    BackupDir='/e/WbmLrvlLrngs/ShellScriptBackups';
    BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}";
    find ./../ -name "Jobs*Exec-*.sh" -type f -print -delete;
    rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && rm -f .env-*;
    # rm -f $RepoFldrTtl.Exec*.sh && rm -f $BackupPath/* && find $BackupDir -type d -empty -print;
    # find . -type d -empty -delete;
    # rm -f $RepoFldrTtl.Exec*.sh $BackupPath/$RepoFldrTtl.Exec*.sh;
    cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    sleep 2 && cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    sleep 2 && cp ./Exec.sh "./$RepoFldrTtl.Exec-$(date +'%m-%d-%y-%r').sh";
    install -D ./*Exec*.sh -m 664 -t $BackupPath;
    tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env >/dev/null
    # install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    rm -f $BackupPath/.env-* && install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    install -D ./All.credentials -m 664 -t $BackupPath;
    cp ~/{.profile,.bashrc,.bash_profile} $BackupPath && cp .git/{config, info/exclude} $BackupPath;
    find $BackupDir -printf "%P\n" | env GZIP=-9 tar -czvf $BackupDir'/ShellScriptBackups.tgz' --no-recursion -C $BackupDir -T -;
    DelAllBkpFls; start '' $BackupDir;
} && export -f bakthisfinalv1;
BakENV() {
    BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}";
    find ./../ -name "Jobs*Exec-*.sh" -type f -print -delete;
    # tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env
    tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env >/dev/null
    # install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
    rm -f $BackupPath/.env-* && install -D ./.env-* -m 664 -t $BackupPath && rm -f .env-*;
} && export -f BakENV;
bakenv() {
    BackupPath="/e/WbmLrvlLrngs/ShellScriptBackups/${PWD##*/}";
    find ./../ -name "Jobs*Exec-*.sh" -type f -print -delete;
    # tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env
    tee "./.env-$(date +'%m-%d-%y-%r')" "$BackupPath/.env-$(date +'%m-%d-%y-%r')" < ./.env >/dev/null
    install -D ./*.env* -m 664 -t $BackupPath && rm -f .env-*;
} && export -f bakenv;

[ -z gitrmtogn ] && declare -fx gitrmtogn
[ -z gitrmtpushurl ] && declare -fx gitrmtpushurl
[ -z gitrmtfetchurl ] && declare -fx gitrmtfetchurl

gitrmtogn() {
    IFS=$'
'
    gitrmtogn=$(git remote show origin)
    echo $gitrmtogn | awk '{ print $6 }'
    unset IFS
};
gitognpushurl=`git remote show origin | egrep "Push\s+URL:(.*)" | awk '{print $3}'`;
gitognfetchurl=`git remote show origin | grep "Fetch URL" | grep -oP '(?<=Fetch URL: ).*'`;
gitrmtpushurl() {
    # eval `git remote show $1 | grep "Push URL" | grep -oP '(?<=Push URL: ).*'`;
    echo `git remote show $1 | egrep "Push\s+URL:(.*)" | awk '{print $3}'`;
}
gitrmtfetchurl() {
    # eval `git remote show $1 | grep "Fetch URL" | grep -oP '(?<=Fetch URL: ).*'`;
    echo `git remote show $1 | grep "Fetch URL" | grep -oP '(?<=Fetch URL: ).*'`;
}
export -f gitrmtpushurl
# user_and_repo="!sh -c '`git remote show $1 | grep \"Fetch URL\" | sed -E \"s/.*github.com[:\\/]([a-zA-Z_\\-]+)\\/([a-zA-Z_\\-]+)\\.git$/\\1 \\2/\"`'";
# alias opn-exec='subl && subl *Exec.sh';
# alias opn-exec='sublime_text && sublime_text *Exec.sh';
alias cp-pch-fls='cp ./*.patch /e/WbmLrvlLrngs/IssueSolutionsCodes';
alias bkp-pch-fls='cp ./*.patch /e/WbmLrvlLrngs/IssueSolutionsCodes';
alias mv-pch-fls='mv ./*.patch /e/WbmLrvlLrngs/IssueSolutionsCodes';
alias scr-pch-fls='mv ./*.patch /e/WbmLrvlLrngs/IssueSolutionsCodes';

## NPM Commands & Snippets starts ##
: '
npm list --depth=0
npm list --depth=0 | grep date
npm list --depth=0 | grep picker
npm list --depth=0 | grep calendar
npm list -g --depth=0
npm list -g --depth=0 | grep date
npm list -g --depth=0 | grep picker
npm list -g --depth=0 | grep calendar
sed "s/.*\(master.*\)/\1/g"
'
# sed "s/.*\(master.*\)/\1/g"
## NPM Commands & Snippets ends ##

alias is-in-git='git rev-parse --is-inside-work-tree >/dev/null 2>&1';
alias prg-lvl-lgs='ls -l storage/logs/*.log >/dev/null 2>/dev/null && rm -f storage/logs/*.log';
alias prg-prj-lgs='ls -l ./*.log >/dev/null && rm -f ./*.log';
alias prg-lgfls-prj='ls -l ./*.log >/dev/null && rm -f ./*.log';

alias ph='. Exec.sh && ClearHistory' && \
alias sa='. Exec.sh && StartArtisan2' && \
alias cac='. Exec.sh && CleanArtisan';

alias ph1='clr-hstr-updt-brchs';
# git branch -a | grep master | sed 's/.*\(master.*\)/\1/g' | sort -u

function npm-self-info {
    Latest=`npm outdated -g npm | awk -vcol=Latest '(NR==1){colnum=-1;for(i=1;i<=NF;i++)if($(i)==col)colnum=i;}{print $(colnum)}' | grep -v Latest`;
    Needed=`npm outdated -g npm | awk -vcol=Wanted '(NR==1){colnum=-1;for(i=1;i<=NF;i++)if($(i)==col)colnum=i;}{print $(colnum)}' | grep -v Wanted`;
    Present=`npm outdated -g npm | awk -vcol=Current '(NR==1){colnum=-1;for(i=1;i<=NF;i++)if($(i)==col)colnum=i;}{print $(colnum)}' | grep -v Current`;
    echo "Latest: $Latest" && echo "Needed: $Needed" && echo "Present: $Present";
    echo "Command: npm i -g npm@next or npm i -g npm@latest or npm install -g npm@<version>";
    echo "Needed version $Needed, so command: npm install -g npm@$Needed";
    echo -n "npm i -g npm@next" | clip.exe && echo "npm i -g npm@next copied...";
}
function npm-self-check {
    Latest=`npm outdated -g npm | awk -vcol=Latest '(NR==1){colnum=-1;for(i=1;i<=NF;i++)if($(i)==col)colnum=i;}{print $(colnum)}' | grep -v Latest`;
    Needed=`npm outdated -g npm | awk -vcol=Wanted '(NR==1){colnum=-1;for(i=1;i<=NF;i++)if($(i)==col)colnum=i;}{print $(colnum)}' | grep -v Wanted`;
    Present=`npm outdated -g npm | awk -vcol=Current '(NR==1){colnum=-1;for(i=1;i<=NF;i++)if($(i)==col)colnum=i;}{print $(colnum)}' | grep -v Current`;
    echo "Latest: $Latest" && echo "Needed: $Needed" && echo "Present: $Present";
    echo "Command: npm i -g npm@next or npm i -g npm@latest or npm install -g npm@<version>";
    echo "Needed version $Needed, so command: npm install -g npm@$Needed";
    echo -n "npm i -g npm@next" | clip.exe && echo "npm i -g npm@next copied...";
}
function npm-self-detail {
    Latest=`npm outdated -g npm | awk -vcol=Latest '(NR==1){colnum=-1;for(i=1;i<=NF;i++)if($(i)==col)colnum=i;}{print $(colnum)}' | grep -v Latest`;
    Needed=`npm outdated -g npm | awk -vcol=Wanted '(NR==1){colnum=-1;for(i=1;i<=NF;i++)if($(i)==col)colnum=i;}{print $(colnum)}' | grep -v Wanted`;
    Present=`npm outdated -g npm | awk -vcol=Current '(NR==1){colnum=-1;for(i=1;i<=NF;i++)if($(i)==col)colnum=i;}{print $(colnum)}' | grep -v Current`;
    echo "Latest: $Latest" && echo "Needed: $Needed" && echo "Present: $Present";
    echo "Command: npm i -g npm@next or npm i -g npm@latest or npm install -g npm@<version>";
    echo "Needed version $Needed, so command: npm install -g npm@$Needed";
    echo -n "npm i -g npm@next" | clip.exe && echo "npm i -g npm@next copied...";
}

function clr-hstr-updt-brchs {
    function clr-hstr { rm -f ~/.bash_history && history -cw && history -wc && reset; }
    clr-hstr && read -ep 'Branches? ' -i 'master,develop' brchs && IFS=, read -ra vars <<<"$brchs";
    function updt-brch {
        o=`git branch -a | grep $1 | sed "s/.*\($1.*\)/\1/g" | sort -u`;
        [ -z != "$o" ] && {
            git checkout -f $1 && git fetch --all -p && git pull && git pull origin;
        }
    }
    for v in "${vars[@]}"; do declare "$v" && updt-brch $v ; done;
    git checkout -f ${vars[-1]} && clr-hstr && git status;
}
function clr-hstr-updt-brchs1 {
    function clr-hstr { rm -f ~/.bash_history && history -cw && history -wc && reset; }
    clr-hstr && read -rp 'Branches: ' brchs && IFS=, read -ra vars <<<"$brchs";
    function updt-brch {
        o=`git branch -a | grep $1 | sed "s/.*\($1.*\)/\1/g" | sort -u`;
        [ -z != "$o" ] && {
            git checkout -f $1 && git fetch --all -p && git pull && git pull origin;
        }
    }
    for v in "${vars[@]}"; do declare "$v" && updt-brch $v ; done;
    git checkout -f ${vars[-1]} && clr-hstr && git status;
}
function clr-hstr-updt-brchs2 {
    function clr-hstr { rm -f ~/.bash_history && history -cw && history -wc && reset; }
    clr-hstr && read -rp 'Branches: ' brchs && IFS=, read -ra vars <<<"$brchs";
    function updt-brch {
        o=`git branch -a | grep $1 | sed "s/.*\($1.*\)/\1/g" | sort -u`;
        [ -z != "$o" ] && {
            git checkout -f $1 && git fetch --all -p && git pull && git pull origin;
        }
    }
    for v in "${vars[@]}"; do declare "$v" && updt-brch $v ; done;
    git checkout -f ${vars[-1]} && clr-hstr && git status;
}


alias diff="git diff -- ':!*lock*' $@" && alias diffc="git diff -- ':!*lock*' $@" && alias diff2="git diff -- ':!*lock*' $@";
alias git-diff2="git diff -- ':!*lock*' $@" && alias git-diffc="git diff -- ':!*lock*' $@";
alias opn-lvl-vue-cmpnnts="start .\\\\resources\\\\js\\\\components\\\\ && start .\\\\resources\\\\js\\\\pages\\\\";
alias opn-lvl-vue-bgtsks="start .\\\\resources\\\\js\\\\backgroundTasks\\\\";
alias opn-lvl-vue-mdls="start .\\\\resources\\\\js\\\\models\\\\";
alias opn-lvl-vue-mxns="start .\\\\resources\\\\js\\\\mixins\\\\";
alias opn-lvl-vue-store="start .\\\\resources\\\\js\\\\store\\\\";
alias opn-lvl-vue-plgns="start .\\\\resources\\\\js\\\\plugins\\\\";

alias npm-chk-inst-lcl="npm list --depth=0 | grep $1";
alias npm-chk-inst-gbl="npm list -g --depth=0 | grep $1";
alias npm-pkg-lcl="npm list --depth=0 | grep $1";
alias npm-pkg-glb="npm list --depth=0 | grep $1";
alias npm-rm-sv="npm rm --save $1";
alias npm-rmv-sv="npm remove --save $1";
alias npm-del-sv="npm delete --save $1";
alias npm-unst-sv="npm uninstall --save $1";
alias npm-rs-i="rm -rf node_modules && rm -f package-lock* && npm cache clean -f && npm install && npm audit fix && npm run watch";
alias npm-rst-i="rm -rf node_modules && rm -f package-lock* && npm cache clean -f && npm install && npm audit fix && npm run watch";
alias npm-rs-u="rm -rf node_modules && rm -f package-lock* && npm cache clean -f && npm update && npm audit fix && npm run watch";
alias npm-rst-u="rm -rf node_modules && rm -f package-lock* && npm cache clean -f && npm update && npm audit fix && npm run watch";

alias opn-etd-fls='subl `git diff --name-only HEAD~ -- '\'':!*lock*'\''`' && \
alias opn-mdfd-fls='subl `git diff --name-only HEAD~ -- '\'':!*lock*'\''`' && \
alias opn-chgd-fls='subl `git diff --name-only HEAD~ -- '\'':!*lock*'\''`' && \
alias opn-chngd-fls='subl `git diff --name-only HEAD~ -- '\'':!*lock*'\''`' && \
alias opn-uptd-fls='subl `git diff --name-only HEAD~ -- '\'':!*lock*'\''`';

alias ph='. Exec.sh && ClearHistory' && \
alias sa='. Exec.sh && StartArtisan2' && \
alias {cac,ca}='. Exec.sh && CleanArtisan';

alias {gub,gusb}='. Exec.sh && UpdateSignfBranches';
alias cmp-nstl='composer clear-cache && rm -f composer.lock && \
COMPOSER_MEMORY_LIMIT=-1 composer install && composer dumpautoload -o';
alias cmp-updt='composer clear-cache && rm -f composer.lock && \
COMPOSER_MEMORY_LIMIT=-1 composer update && composer dumpautoload -o';
alias cmp-rst-nstl='rm -f composer.lock && composer clear-cache && rm -f composer.lock && \
COMPOSER_MEMORY_LIMIT=-1 composer install && composer dumpautoload && composer dumpautoload -o';
alias cmp-rst-nstl0='rm -f composer.lock && composer clear-cache && rm -f composer.lock && \
COMPOSER_MEMORY_LIMIT=-1 composer install && composer dumpautoload && composer dumpautoload -o';
alias cmp-rst-nstl1='composer clear-cache && rm -rf vendor/ && rm -f composer.lock && \
COMPOSER_MEMORY_LIMIT=-1 composer install && composer dumpautoload && composer dumpautoload -o';
alias cmp-rst-nstl2='composer clear-cache && rm -rf vendor/ && rm -f composer.lock && \
COMPOSER_MEMORY_LIMIT=-1 composer install && composer dumpautoload && composer dumpautoload -o';
alias npm-nstl='npm cache clean -f && npm install && npm audit fix && npm run dev';
alias npm-nstl0='npm cache clean -f && npm install && npm audit fix && npm run watch';
alias npm-nstl-f='rm -rf node_modules && rm -f package-lock* && npm cache clean -f && npm install && npm audit fix && npm run dev;';
alias npm-nstl-f0='rm -rf node_modules && rm -f package-lock* && npm cache clean -f && npm install && npm audit fix && npm run watch';
alias npm-nstl-rf='rm -rf node_modules && rm -f package-lock* && npm cache clean -f && npm install && npm audit fix && npm run dev;';
alias npm-nstl-rf0='rm -rf node_modules && rm -f package-lock* && npm cache clean -f && npm install && npm audit fix && npm run watch';
alias npm-nstl-bf='rm -rf node_modules && rm -f package-lock* && npm cache clean -f && npm install && npm audit fix && npm run dev;';
alias npm-nstl-bf0='rm -rf node_modules && rm -f package-lock* && npm cache clean -f && npm install && npm audit fix && npm run watch';
alias npm-nstl-bf00='rm -rf $APPDATA/npm/_
cacache && rm -rf node_modules && rm -f package-lock* && npm cache clean -f && npm install && npm audit fix && npm run dev';
alias npm-nstl-bf01='rm -rf $APPDATA/npm/_
cacache && rm -rf node_modules && rm -f package-lock* && npm cache clean -f && npm install && npm audit fix && npm run watch';
alias php-unit='vendor/phpunit/phpunit/phpunit';

alias gt-ssh-{l,s}='[[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k';

alias ph='. Exec.sh && ClearHistory' && alias sa='. Exec.sh && StartArtisan2' && alias cac='. Exec.sh && CleanArtisan';
alias mkbr='. Exec.sh && CrtFrshBrnchFrmDvlp'
alias gtrst='[ "`git rev-parse --git-dir`" == ".git" ] && git restore public/ storage/ && ph && git diff';
alias gtrstv1='[ "`git rev-parse --git-dir`" == ".git" ] && git restore public/ storage/ && ClearHistory';
alias gtrst1='[ "`git rev-parse --git-dir`" == ".git" ] && git restore public/ storage/ && ClearHistory && UpdateSignfBranches';
alias gtrst1v1='[ "`git rev-parse --git-dir`" == ".git" ] && git restore public/ storage/ && ClearHistory && UpdateSignfBranches';
alias rvrt-rntm-dirs='[ "`git rev-parse --git-dir`" == ".git" ] && git restore public/ storage/';

alias gdif="git diff -- ':!*.lock' ':!*.json' > temp.diff";
alias gdif-prnt="git diff -- ':!*.lock' ':!*.json' > temp_`date +%F_%T`.diff";
alias ss-run=". Exec.sh && RunService 'backend'" && alias cs-run=". Exec.sh && RunService 'frontend'";
alias gtrst-stgd-fls='{ filePath=$(cat -) && git reset HEAD $filePath && git restore $filePath; }<<< && git diff';
alias gstsh-stgd='[ "`git rev-parse --git-dir`" == ".git" ] && git stash --keep-index && git stash push -m "`git branch --show-current`-Stgd" && git diff';
alias gstsh-stgd2='git stash push -m "`git branch --show-current`-Stgd" -- `git diff --staged --name-only --diff-filter=ACM` && git diff';
alias gstsh-stgd3='git stash push -m "`git branch --show-current`-Stgd" -- `git diff --staged --name-only --diff-filter=ACM` && git diff';

### Bash commands that comes handy ###

# cp Exec{,_`date +%F`.sh}
# cp Exec.sh{,_`date +%F`.sh}
# cp Exec.sh{,_`date +%F_%T`.sh}
# cp Exec.sh Exec_`date +%F`.sh
# cp Exec.sh Exec_`date +%F_%T`.sh
# cp Exec.sh Exec_`date +%F`.sh Exec_`date +%F_%T`.sh

# cp .git/config GitConfig_`date +%F`.sh
# cp .git/config GitConfig_`date +%F_%T`.sh
# cp .git/config GitConfig_`date +%F`.gitconfig
# cp .git/config GitConfig_`date +%F_%T`.gitconfig

# cp .git/config GitConfig_`date +%F`.gitconfig && cp Exec.sh{,_`date +%F`.sh}
# cp .git/config GitConfig_`date +%F_%T`.gitconfig && cp Exec.sh{,_`date +%F_%T`.sh}

# mv Exec.sh Exec_`date +%F`.sh
# mv Exec.sh Exec_`date +%F_%T`.sh
## cp /path/to/file/file1{,.kbp}

# eval `ssh-agent -s` && ssh-add -k;

# git log `git branch -r | grep <BId>` --since="yesterday" -p > <BID>_`date +%Y-%m-%d_%H-%M-%S`.patch;
# git reset --hard HEAD && git merge <FeatureBranch> --no-edit && git push origin <ParentBranch> && git co <FeatureBranch>;
# git reset --hard HEAD && git merge rdmp-304/hotfix/Whitelist-IPRange --no-edit && git push origin staging && git co rdmp-304/hotfix/Whitelist-IPRange;
# git clean -n && git clean -f && composer dump-autoload -o
# git clean -n && git clean -fd && composer dump-autoload -o
# git clean -n && git clean -df && composer dump-autoload -o
# git clean -n && git clean -f -d && composer dump-autoload -o

# BackupBashExec()
# {
#     [ "$pwd" != "/c/network-sites" ] && cd "/c/network-sites";
#     history -cw && history -wc && reset && clear && rm -f $HISTFILE;
#     cp .git/config GitConfig_`date +%F`.gitconfig && cp Exec.sh{,_`date +%F`.sh}
#     cp .git/config GitConfig_`date +%F_%T`.gitconfig && cp Exec.sh{,_`date +%F_%T`.sh}
#     cp .gitaliases GitAliases_`date +%F`.gitaliases && cp .gitaliases GitAliases_`date +%F_%T`.gitaliases
# }

# Network Sites project domains
: '
http://staging.bestdriverjobs.com
http://staging.1truckdriverjobs.com - not active
http://staging.bigtruckdrivingjobs.com
http://staging.bigrigjobs.com
http://staging.hiringtruckdrivers.com
http://staging.owneroperator.com
http://staging.jobsforteams.com
'
____='
http://staging.bestdriverjobs.com
http://staging.1truckdriverjobs.com - not active
http://staging.bigtruckdrivingjobs.com
http://staging.bigrigjobs.com
http://staging.hiringtruckdrivers.com
http://staging.owneroperator.com
http://staging.jobsforteams.com
'
ChkLrvlLogs(){
    ls -t1 ./storage/logs | tail -n +2 | xargs echo rm -f && subl `find . -name '*.log'`;
    # ls -t1 ./storage/logs | tail -n +2 | xargs echo rm -f && subl `find . -name '*.log'`;
    # ls -t1 ./storage/logs | tail -n +2 | xargs echo rm -f && subl `find . -name '*.log'`;
    # ls -t1 ./storage/logs | tail -n +2 | xargs echo rm -f && subl `find . -name '*.log'`;
}
RvrtLstMgrtn()
{
    read -p "Revert last migration ? " -n 1 -r;
    [[ $REPLY =~ ^[Yy]$ ]] && php artisan migrate:rollback;
}
LrvlMgrtOnly(){
    ## For customized-full rollback process, refer All.credentials
    ## and then run this below command in GitBash/Bash like:
    # `LrvlMgrtOnly job_filters`; OR ...
    ## Run this queries in the DB:
    : 'SELECT * FROM `recruiting`.`migrations` WHERE `migration` LIKE '%job_filters%';
    DELETE FROM `recruiting`.`migrations` WHERE `migration` LIKE '%job_filters%';
    DROP TABLE IF EXISTS `recruiting`.`job_filters`;'
    # php artisan migrate --path=`find ./ -name *$1* -type f`;
    find ./ -name *$1* -type f -exec php artisan migrate --path={} \;
    # find ./ -name *$1* -type f -exec php artisan migrate --path='{}' \;
    # find ./ -name *$1* -type f -exec php artisan migrate --path="{}" \;
}
LrvlMgrtOnlyDone(){
    ## For customized-full rollback process, refer All.credentials
    ## and then run this below command in GitBash/Bash like:
    # `LrvlMgrtOnly job_filters`; OR ...
    ## Run this queries in the DB:
    : 'SELECT * FROM `recruiting`.`migrations` WHERE `migration` LIKE '%job_filters%';
    DELETE FROM `recruiting`.`migrations` WHERE `migration` LIKE '%job_filters%';
    DROP TABLE IF EXISTS `recruiting`.`job_filters`;'
    # php artisan migrate --path=`find ./ -name *$1* -type f`;
    find ./ -name *$1* -type f -exec php artisan migrate --path={} \;
    # find ./ -name *$1* -type f -exec php artisan migrate --path='{}' \;
    # find ./ -name *$1* -type f -exec php artisan migrate --path="{}" \;
}
LrvlMgrtOnlyFinal(){
    ## For customized-full rollback process, refer All.credentials
    ## and then run this below command in GitBash/Bash like:
    # `LrvlMgrtOnly job_filters`; OR ...
    ## Run this queries in the DB:
    : 'SELECT * FROM `recruiting`.`migrations` WHERE `migration` LIKE '%job_filters%';
    DELETE FROM `recruiting`.`migrations` WHERE `migration` LIKE '%job_filters%';
    DROP TABLE IF EXISTS `recruiting`.`job_filters`;'
    # php artisan migrate --path=`find ./ -name *$1* -type f`;
    find ./ -name *$1* -type f -exec php artisan migrate --path={} \;
    # find ./ -name *$1* -type f -exec php artisan migrate --path='{}' \;
    # find ./ -name *$1* -type f -exec php artisan migrate --path="{}" \;
}
LrvlMgrtOnlyUsable(){
    ## For customized-full rollback process, refer All.credentials
    ## and then run this below command in GitBash/Bash like:
    # `LrvlMgrtOnly job_filters`; OR ...
    ## Run this queries in the DB:
    : 'SELECT * FROM `recruiting`.`migrations` WHERE `migration` LIKE '%job_filters%';
    DELETE FROM `recruiting`.`migrations` WHERE `migration` LIKE '%job_filters%';
    DROP TABLE IF EXISTS `recruiting`.`job_filters`;'
    # php artisan migrate --path=`find ./ -name *$1* -type f`;
    find ./ -name *$1* -type f -exec php artisan migrate --path={} \;
    # find ./ -name *$1* -type f -exec php artisan migrate --path='{}' \;
    # find ./ -name *$1* -type f -exec php artisan migrate --path="{}" \;
}
LrvlMgrt(){ RvrtLstMgrtn && php artisan migrate --path=`find ./ -name *$1* -type f`; }
LrvlMgrt1(){ RvrtLstMgrtn || php artisan migrate --path=`find ./ -name *$1* -type f`; }
LrvlMgrt2(){ RvrtLstMgrtn & php artisan migrate --path=`find ./ -name *$1* -type f`; }
LrvlMgrtFnl(){ RvrtLstMgrtn && php artisan migrate --path=`find ./ -name *$1* -type f`; }
LrvlMgrtRdy(){ RvrtLstMgrtn && php artisan migrate --path=`find ./ -name *$1* -type f`; }
LrvlMgrtWrkng(){ RvrtLstMgrtn && php artisan migrate --path=`find ./ -name *$1* -type f`; }
LrvlMgrtRlbckStps() {
    # Use 0 for true and 1 for false when return(ing).
    CheckArg() { if ! [[ "$1" =~ ^[1-9]+$ ]]; then return 1; else return 0; fi; }
    if [ -z "$*" ]; then
        read -rp 'Step(s) you wanna rollback? ' step;
        if ! CheckArg $step; then
            echo 'Invalid param' && return 1 2>/dev/null && exit 1;
        fi;
        php artisan migrate:rollback --step=$step;
    else
        if ! CheckArg $1; then
            echo 'Invalid param' && return 1 2>/dev/null && exit 1;
        fi;
        php artisan migrate:rollback --step=$1;
    fi;
}
LrvlMgrtRlbckStpsDone() {
    # Use 0 for true and 1 for false when return(ing).
    CheckArg() { if ! [[ "$1" =~ ^[1-9]+$ ]]; then return 1; else return 0; fi; }
    if [ -z "$*" ]; then
        read -rp 'Step(s) you wanna rollback? ' step;
        if ! CheckArg $step; then
            echo 'Invalid param' && return 1 2>/dev/null && exit 1;
        fi;
        php artisan migrate:rollback --step=$step;
    else
        if ! CheckArg $1; then
            echo 'Invalid param' && return 1 2>/dev/null && exit 1;
        fi;
        php artisan migrate:rollback --step=$1;
    fi;
}

GitCloneAnyBranch() {
    CrntBrnch=`git branch --show-current` && CWD=$(pwd);
    git checkout $1 && git fetch --all -p && git pull && git pull origin;
    git checkout $CrntBrnch && pwd=$(pwd) && mkdir $1 && cd $1 && git init;
    git remote add -t $1 -f origin $gitognfetchurl && git checkout $1;
    # XZ_OPT=-9 tar cJf "$pwd/$1-$(date +'%m-%d-%y-%r').tar.xz" $pwd/$1/;
    XZ_OPT=-e9 tar cJf "$pwd/$1-$(date +'%m-%d-%y-%r').tar.xz" $pwd/$1/;
    # env GZIP=-9 tar cvzf "$pwd/$1-$(date +'%m-%d-%y-%r').tar.gz" $pwd/$1/;
    # git checkout $1 && tar -cf - $pwd/$1/ | xz -9 -c - > $pwd/$1.tar.xz;
    # cd ../ && rm -rf ./$1 && cp ./*.tar.xz /e/WbmLrvlLrngs/BranchCloneBackups;
    cd ../ && rm -rf ./$1 && mv ./*.tar.xz /e/WbmLrvlLrngs/BranchCloneBackups;
}
GitCloneAnyBranchv1() {
    CrntBrnch=`git branch --show-current` && CWD=$(pwd);
    git checkout $1 && git fetch --all -p && git pull && git pull origin;
    git checkout $CrntBrnch && pwd=$(pwd) && mkdir $1 && cd $1 && git init;
    git remote add -t $1 -f origin $gitognfetchurl && git checkout $1;
    # XZ_OPT=-9 tar cJf "$pwd/$1-$(date +'%m-%d-%y-%r').tar.xz" $pwd/$1/;
    XZ_OPT=-e9 tar cJf "$pwd/$1-$(date +'%m-%d-%y-%r').tar.xz" $pwd/$1/;
    # env GZIP=-9 tar cvzf "$pwd/$1-$(date +'%m-%d-%y-%r').tar.gz" $pwd/$1/;
    # git checkout $1 && tar -cf - $pwd/$1/ | xz -9 -c - > $pwd/$1.tar.xz;
    # cd ../ && rm -rf ./$1 && cp ./*.tar.xz /e/WbmLrvlLrngs/BranchCloneBackups;
    cd ../ && rm -rf ./$1 && mv ./*.tar.xz /e/WbmLrvlLrngs/BranchCloneBackups;
}
GitCloneSingleBranch() {
    CrntBrnch=`git branch --show-current` && CWD=$(pwd);
    git checkout $1 && git fetch --all -p && git pull && git pull origin;
    git checkout $CrntBrnch && pwd=$(pwd) && mkdir $1 && cd $1 && git init;
    git remote add -t $1 -f origin $gitognfetchurl && git checkout $1;
    # XZ_OPT=-9 tar cJf "$pwd/$1-$(date +'%m-%d-%y-%r').tar.xz" $pwd/$1/;
    XZ_OPT=-e9 tar cJf "$pwd/$1-$(date +'%m-%d-%y-%r').tar.xz" $pwd/$1/;
    # env GZIP=-9 tar cvzf "$pwd/$1-$(date +'%m-%d-%y-%r').tar.gz" $pwd/$1/;
    # git checkout $1 && tar -cf - $pwd/$1/ | xz -9 -c - > $pwd/$1.tar.xz;
    # cd ../ && rm -rf ./$1 && cp ./*.tar.xz /e/WbmLrvlLrngs/BranchCloneBackups;
    cd ../ && rm -rf ./$1 && mv ./*.tar.xz /e/WbmLrvlLrngs/BranchCloneBackups;
}
GitCloneSingleBranchv1() {
    CrntBrnch=`git branch --show-current` && CWD=$(pwd);
    git checkout $1 && git fetch --all -p && git pull && git pull origin;
    git checkout $CrntBrnch && pwd=$(pwd) && mkdir $1 && cd $1 && git init;
    git remote add -t $1 -f origin $gitognfetchurl && git checkout $1;
    # XZ_OPT=-9 tar cJf "$pwd/$1-$(date +'%m-%d-%y-%r').tar.xz" $pwd/$1/;
    XZ_OPT=-e9 tar cJf "$pwd/$1-$(date +'%m-%d-%y-%r').tar.xz" $pwd/$1/;
    # env GZIP=-9 tar cvzf "$pwd/$1-$(date +'%m-%d-%y-%r').tar.gz" $pwd/$1/;
    # git checkout $1 && tar -cf - $pwd/$1/ | xz -9 -c - > $pwd/$1.tar.xz;
    # cd ../ && rm -rf ./$1 && cp ./*.tar.xz /e/WbmLrvlLrngs/BranchCloneBackups;
    cd ../ && rm -rf ./$1 && mv ./*.tar.xz /e/WbmLrvlLrngs/BranchCloneBackups;
}

UpdateSignfBranches()
{
    git reflog expire --all --expire=now && git gc --prune=now --aggressive;
    SshPassValidv2 & RepoUrl=`git config --get remote.origin.url`;
    CBrnh=`git branch --show-current`;
    SBrnchs=('stage' 'staging' 'master' 'develop');
    for SBrnch in ${SBrnchs[*]}; do
        git ls-remote --heads $RepoUrl $SBrnch && (
            git checkout $SBrnch && git pull origin;
        ) || (
            git fetch --all -p && continue;
        )
    done;
    read -p 'Track current branch? ' doTrack && [[ $doTrack =~ ^[Yy]$ ]] \
    && git branch --set-upstream-to=origin/${CBrnh} $CBrnh;
    git checkout $CBrnh && git pull && git pull origin;
}

UpdateImptntBranches()
{
    git reflog expire --all --expire=now && git gc --prune=now --aggressive;
    SshPassValidv2 & RepoUrl=`git config --get remote.origin.url`;
    CBrnh=`git branch --show-current`;
    SBrnchs=('stage' 'staging' 'master' 'develop');
    for SBrnch in ${SBrnchs[*]}; do
        git ls-remote --heads $RepoUrl $SBrnch && (
            git checkout $SBrnch && git pull origin;
        ) || (
            git fetch --all -p && continue;
        )
    done;
    read -p 'Track current branch? ' doTrack && [[ $doTrack =~ ^[Yy]$ ]] \
    && git branch --set-upstream-to=origin/${CBrnh} $CBrnh;
    git checkout $CBrnh && git pull && git pull origin;
}

UpdateMainParentBranches()
{
    git reflog expire --all --expire=now && git gc --prune=now --aggressive;
    SshPassValidv2 & RepoUrl=`git config --get remote.origin.url`;
    CBrnh=`git branch --show-current`;
    SBrnchs=('stage' 'staging' 'master' 'develop');
    for SBrnch in ${SBrnchs[*]}; do
        git ls-remote --heads $RepoUrl $SBrnch && (
            git checkout $SBrnch && git pull origin;
        ) || (
            git fetch --all -p && continue;
        )
    done;
    read -p 'Track current branch? ' doTrack && [[ $doTrack =~ ^[Yy]$ ]] \
    && git branch --set-upstream-to=origin/${CBrnh} $CBrnh;
    git checkout $CBrnh && git pull && git pull origin;
}

CleanArtisan()
{
    ls -l storage/logs/*.log >/dev/null 2>/dev/null && rm -f storage/logs/*.log;
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    composer clear-cache && composer dumpautoload -o;
    php artisan cache:clear && php artisan route:clear && php artisan config:clear && php artisan view:clear;
    php artisan config:cache && php artisan route:cache && php artisan clear-compiled && php artisan optimize -f;
}

StartArtisan()
{
    ls -l storage/logs/*.log >/dev/null 2>/dev/null && rm -f storage/logs/*.log;
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    composer clear-cache && composer dumpautoload -o;
    php artisan cache:clear && php artisan route:clear && php artisan view:clear;
    php artisan clear-compiled && php artisan config:clear && php artisan config:cache;
    php artisan optimize -f;
    echo -n "Port ? (To keep default port hit n/N or type port no.)" && read answer;
    if [[ "$answer" =~ ^[Nn]$ ]]; then php artisan serve; else php artisan serve --port=$answer; fi;
}

StartArtisan2()
{
    ls -l storage/logs/*.log >/dev/null 2>/dev/null && rm -f storage/logs/*.log;
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    rm -fr storage/logs/* && rm -fr bootstrap/cache/* && rm -fr storage/framework/cache/*\
     && rm -fr storage/framework/sessions/* && composer dump-autoload && php artisan optimize;
    composer clear-cache && composer dumpautoload -o && npm cache clean -f && npm run dev;
    php artisan cache:clear && php artisan route:clear && php artisan view:clear;
    php artisan clear-compiled && php artisan config:clear && php artisan config:cache;
    echo -n "Port ? (To keep default port hit n/N or type port no.)" && read answer;
    if [[ "$answer" =~ ^[Nn]$ ]]; then php artisan serve; else php artisan serve --port=$answer; fi;
}

RunServiceOld()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    ls -l storage/logs/*.log >/dev/null 2>/dev/null && rm -f storage/logs/*.log;
    if [ "$1" == "backend" ] || [ "$1" == "server" ]; then
        read -p "Port ? [default:8000] "port && port=${port:-8000}
        ls -l storage/logs/*.log >/dev/null 2>/dev/null && rm -f storage/logs/*.log;
        SweepFolders && php artisan cache:clear && php artisan view:clear \
        && php artisan clear-compiled && php artisan optimize && php artisan serve --port=$port;
    else
        npm cache clean -f && npm audit fix && npm run watch;
        ls -l storage/logs/*.log >/dev/null 2>/dev/null && rm -f storage/logs/*.log;
        # SweepFolders && npm cache clean -f && npm run watch;
        # rm -rf node_modules && npm cache clean -f && npm install && npm audit fix && npm run watch;
    fi;
}

RunServiceOld2()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    ls -l storage/logs/*.log >/dev/null 2>/dev/null && rm -f storage/logs/*.log;
    if [ "$1" == "backend" ] || [ "$1" == "server" ]; then
        read -p "Port ? [default:8000] "port && port=${port:-8000}
        ls -l storage/logs/*.log >/dev/null 2>/dev/null && rm -f storage/logs/*.log;
        SweepFolders && php artisan cache:clear && php artisan view:clear \
        && php artisan clear-compiled && php artisan optimize && php artisan serve --port=$port;
    else
        npm cache clean -f && npm audit fix && npm run watch;
        ls -l storage/logs/*.log >/dev/null 2>/dev/null && rm -f storage/logs/*.log;
        # SweepFolders && npm cache clean -f && npm run watch;
        # rm -rf node_modules && npm cache clean -f && npm install && npm audit fix && npm run watch;
    fi;
}

## To run artisan service in background when closed from terminal
## and the 2nd command to kill the running service later
# nohup php artisan serve &
# ps -ef | grep "$PWD/server.php"

ResetUpdateCodebase() {
    read -r -p 'Reset & Update Codebase? [Y/n] ' opt && opt=${opt,,} && [[ "$opt" =~ ^(yes|y)$ ]] && {
        [ "`git rev-parse --git-dir`" == ".git" ] && git restore public/ storage && UpdateSignfBranches;
    }
}
ResetUpdateCodebaseDone() {
    read -r -p 'Reset & Update Codebase? [Y/n] ' opt && opt=${opt,,} && [[ "$opt" =~ ^(yes|y)$ ]] && {
        [ "`git rev-parse --git-dir`" == ".git" ] && git restore public/ storage && UpdateSignfBranches;
    }
}
ResetUpdateCodebaseFinal() {
    read -r -p 'Reset & Update Codebase? [Y/n] ' opt && opt=${opt,,} && [[ "$opt" =~ ^(yes|y)$ ]] && {
        [ "`git rev-parse --git-dir`" == ".git" ] && git restore public/ storage && UpdateSignfBranches;
    }
}
ResetUpdateCodebaseUsable() {
    read -r -p 'Reset & Update Codebase? [Y/n] ' opt && opt=${opt,,} && [[ "$opt" =~ ^(yes|y)$ ]] && {
        [ "`git rev-parse --git-dir`" == ".git" ] && git restore public/ storage && UpdateSignfBranches;
    }
}

RunService()
{
    ResetUpdateCodebase; ClearHistory;
    if [ "$1" == 'backend' ] || [ "$1" == 'server' ]; then
        if [ "${PWD##*/}" == 'jobs-platform' ]; then LumenStart;
        else LaravelStart; fi;
    else
        SweepFolders && npm cache clean -f && npm audit fix && npm run watch;
    fi;
}
RunServiceDone()
{
    ResetUpdateCodebase; ClearHistory;
    if [ "$1" == 'backend' ] || [ "$1" == 'server' ]; then
        if [ "${PWD##*/}" == 'jobs-platform' ]; then LumenStart;
        else LaravelStart; fi;
    else
        SweepFolders && npm cache clean -f && npm audit fix && npm run watch;
    fi;
}
RunServiceFinal()
{
    ResetUpdateCodebase; ClearHistory;
    if [ "$1" == 'backend' ] || [ "$1" == 'server' ]; then
        if [ "${PWD##*/}" == 'jobs-platform' ]; then LumenStart;
        else LaravelStart; fi;
    else
        SweepFolders && npm cache clean -f && npm audit fix && npm run watch;
    fi;
}
RunServiceUsable()
{
    ResetUpdateCodebase; ClearHistory;
    if [ "$1" == 'backend' ] || [ "$1" == 'server' ]; then
        if [ "${PWD##*/}" == 'jobs-platform' ]; then LumenStart;
        else LaravelStart; fi;
    else
        SweepFolders && npm cache clean -f && npm audit fix && npm run watch;
    fi;
}

LumenStart() {
    rm -f storage/logs/*.log 2> /dev/null;
    read -p 'Port? [80]: 'port && port=${port:-80};
    SweepFolders && php -S 127.0.0.1:$port -t ./public;
}
LumenStartDone() {
    rm -f storage/logs/*.log 2> /dev/null;
    read -p 'Port? [80]: 'port && port=${port:-80};
    SweepFolders && php -S 127.0.0.1:$port -t ./public;
}
LumenStartFinal() {
    rm -f storage/logs/*.log 2> /dev/null;
    read -p 'Port? [80]: 'port && port=${port:-80};
    SweepFolders && php -S 127.0.0.1:$port -t ./public;
}
LumenStartUsable() {
    rm -f storage/logs/*.log 2> /dev/null;
    read -p 'Port? [80]: 'port && port=${port:-80};
    SweepFolders && php -S 127.0.0.1:$port -t ./public;
}

ArtisanStartBg(){
    rm -f storage/logs/*.log 2> /dev/null;
    read -p 'Port? [8000]: 'port && port=${port:-8000};
    composer clear-cache && composer dump-autoload && composer dump-autoload -o;
    rm -fr bootstrap/cache/* && rm -fr storage/framework/cache/* && php artisan clear-compiled;
    php artisan cache:clear && php artisan view:cache && php artisan config:cache && php artisan event:cache && php artisan route:cache && php artisan optimize && nohup php artisan serve --port=$port &
    echo To kill this later run:'ps -ef | grep "$PWD/server.php"';
    echo -n 'ps -ef | grep "$PWD/server.php"' | clip.exe;
    ## For lumen: nohup php -S localhost:8000 -t ./public &
    ## For lumen: nohup php -S localhost:80 -t ./public &
    ## To check and kill: ps -ef | grep '/php' | awk '{print $2}'
    ## For program with custom out-file: nohup myprogram > myprogram.out 2> myprogram.err
    ## For lumen with both output & error in 1 file: nohup php -S localhost:8000 -t ./public > ../jobs-platform.out 2>&1
    ## For lumen with both output & error in 1 file: nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1
    ## For lumen with different output & error files: nohup php -S localhost:8000 -t ./public > ../jobs-platform.out 2> ../jobs-platform.err
    ## For lumen with different output & error files: nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2> ../jobs-platform.err

}
ArtisanStartInBg(){
    rm -f storage/logs/*.log 2> /dev/null;
    read -p 'Port? [8000]: 'port && port=${port:-8000};
    composer clear-cache && composer dump-autoload && composer dump-autoload -o;
    rm -fr bootstrap/cache/* && rm -fr storage/framework/cache/* && php artisan clear-compiled;
    php artisan cache:clear && php artisan view:cache && php artisan config:cache && php artisan event:cache && php artisan route:cache && php artisan optimize && nohup php artisan serve --port=$port &
    echo To kill this later run:'ps -ef | grep "$PWD/server.php"';
    echo -n 'ps -ef | grep "$PWD/server.php"' | clip.exe;
    ## For lumen: nohup php -S localhost:8000 -t ./public &
    ## For lumen: nohup php -S localhost:80 -t ./public &
    ## To check and kill: ps -ef | grep '/php' | awk '{print $2}'
    ## For program with custom out-file: nohup myprogram > myprogram.out 2> myprogram.err
    ## For lumen with both output & error in 1 file: nohup php -S localhost:8000 -t ./public > ../jobs-platform.out 2>&1
    ## For lumen with both output & error in 1 file: nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1
    ## For lumen with different output & error files: nohup php -S localhost:8000 -t ./public > ../jobs-platform.out 2> ../jobs-platform.err
    ## For lumen with different output & error files: nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2> ../jobs-platform.err
}
ArtisanStartBackground(){
    rm -f storage/logs/*.log 2> /dev/null;
    read -p 'Port? [8000]: 'port && port=${port:-8000};
    composer clear-cache && composer dump-autoload && composer dump-autoload -o;
    rm -fr bootstrap/cache/* && rm -fr storage/framework/cache/* && php artisan clear-compiled;
    php artisan cache:clear && php artisan view:cache && php artisan config:cache && php artisan event:cache && php artisan route:cache && php artisan optimize && nohup php artisan serve --port=$port &
    echo To kill this later run:'ps -ef | grep "$PWD/server.php"';
    echo -n 'ps -ef | grep "$PWD/server.php"' | clip.exe;
    ## For lumen: nohup php -S localhost:8000 -t ./public &
    ## For lumen: nohup php -S localhost:80 -t ./public &
    ## To check and kill: ps -ef | grep '/php' | awk '{print $2}'
    ## For program with custom out-file: nohup myprogram > myprogram.out 2> myprogram.err
    ## For lumen with both output & error in 1 file: nohup php -S localhost:8000 -t ./public > ../jobs-platform.out 2>&1
    ## For lumen with both output & error in 1 file: nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1
    ## For lumen with different output & error files: nohup php -S localhost:8000 -t ./public > ../jobs-platform.out 2> ../jobs-platform.err
    ## For lumen with different output & error files: nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2> ../jobs-platform.err
}

## For lumen: nohup php -S localhost:8000 -t ./public &
## For lumen: nohup php -S localhost:80 -t ./public &
## To check and kill: ps -ef | grep '/php' | awk '{print $2}'
## For program with custom out-file: nohup myprogram > myprogram.out 2> myprogram.err
## For lumen with both output & error in 1 file: nohup php -S localhost:8000 -t ./public > ../jobs-platform.out 2>&1
## For lumen with both output & error in 1 file: nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1
### > nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1
## For lumen with different output & error files: nohup php -S localhost:8000 -t ./public > ../jobs-platform.out 2> ../jobs-platform.err
## For lumen with different output & error files: nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2> ../jobs-platform.err

LumenStartInBg(){
    ## For lumen: nohup php -S localhost:8000 -t ./public &
    ## For lumen: nohup php -S localhost:80 -t ./public &
    ## To check and kill: ps -ef | grep '/php' | awk '{print $2}'
    ## For program with custom out-file: nohup myprogram > myprogram.out 2> myprogram.err
    ## For lumen with both output & error in 1 file: nohup php -S localhost:8000 -t ./public > ../jobs-platform.out 2>&1
    ## For lumen with both output & error in 1 file: nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1
    ## For lumen with different output & error files: nohup php -S localhost:8000 -t ./public > ../jobs-platform.out 2> ../jobs-platform.err
    ## For lumen with different output & error files: nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2> ../jobs-platform.err
    ## For both laravel and lumen servers:
    : '
    nohup php -S localhost -t ./public > ../jobs-platform.out 2>&1 &
    nohup php artisan serve --port=8000  > ../jobs-client-ui.out 2>&1 &
    nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1 &
    nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1 & nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1 &
    nohup php -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1 &
    taskkill -f -im php.exe && kill -9 $$
    taskkill -f -im php.exe && kill -9 $$
    taskkill -f -im php.exe && kill -9 $$
    taskkill -f -im php.exe && kill -9 $$
    '
    : '
    nohup php artisan serve --port=8000  > ../jobs-client-ui.out 2>&1 &
    nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1 &
    nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1 & nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1 &
    nohup php -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1 &
    taskkill -f -im php.exe && kill -9 $$
    taskkill -f -im php.exe && kill -9 $$
    taskkill -f -im php.exe && kill -9 $$
    taskkill -f -im php.exe && kill -9 $$
    '
    : '
    nohup php artisan serve --port=8000  > ../jobs-client-ui.out 2>&1 &
    nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1 &
    nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1 & nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1 &
    nohup php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1 & php -S localhost:80 -t ./public > ../jobs-platform.out 2>&1 &
    nohup php -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & nohup php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 &
    taskkill -f -im php.exe && kill -9 $$
    taskkill -f -im php.exe && kill -9 $$
    taskkill -f -im php.exe && kill -9 $$
    taskkill -f -im php.exe && kill -9 $$

    nohup php -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & nohup php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 &
    nohup php -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & nohup php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 &
    nohup php -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & nohup php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 &
    nohup php -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & nohup php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 &
    nohup php -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & nohup php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 &
    php -S localhost:80 -t ../jobs-platform/public > /dev/null 2>&1 & disown
    php artisan serve --port=8000 > /dev/null 2>&1 & disown
    php -S localhost:80 -t ../jobs-platform/public > /dev/null 2>&1 & disown
    php artisan serve --port=8000 > /dev/null 2>&1 & disown & ps -eaf
    ps -ef | grep 'myProcessName' | grep -v grep | awk '{print $2}' | xargs -r kill -9
    ps -eaf | awk "/php|winpty/ && !/awk/{print $3}" | sort -u
    '
    : "
    ps -eaf | awk '/php|winpty/ && !/awk/{print $3}' | sort -u
    kill `ps -eaf | awk '/php|winpty/ && !/awk/{print $3}' | sort -u`
    kill $(ps -eaf | awk '/php|winpty/ && !/awk/{print $3}' | sort -u)

    ### Final developed/debugged/troubleshooted code for starting servers in BG(background):
    taskkill -f -t -im php.exe && kill -9 $$
    php.exe -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & disown #lumen
    php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 & disown #laravel-artisan
    taskkill -f -t -im php.exe && kill -9 $$
    php.exe -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & disown
    php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 & disown
    taskkill -f -t -im php.exe && kill -9 $$;
    php.exe -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & disown;
    php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 & disown;
    taskkill -f -t -im php.exe && kill -9 $$;
    taskkill -f -t -im php.exe -im winpty.exe;
    tasklist -fi 'imagename eq php.exe' & taskkill -f -t -im php.exe
    tasklist -fi 'imagename eq php.exe' & taskkill -f -t -im php.exe
    tasklist -fi 'imagename eq php.exe' & taskkill -f -t -im php.exe
    tasklist -fi 'imagename eq php.exe' & taskkill -f -t -im php.exe
    ## winpty php -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & disown;
    winpty php.exe -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & disown;
    winpty php -S localhost:80 -t ../jobs-platform/public > /dev/null 2>&1 & disown;
    winpty php.exe -S localhost:80 -t ../jobs-platform/public > /dev/null 2>&1 & disown;
    winpty.exe php -S localhost:80 -t ../jobs-platform/public > /dev/null 2>&1 & disown;
    php -S localhost:80 -t ../jobs-platform/public > /dev/null 2>&1 & disown;
    php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 & disown;
    Working and ready:
    winpty php -S localhost:80 -t ../jobs-platform/public > /dev/null 2>&1 & disown;
    winpty php -S localhost:80 -t ../jobs-platform/public > /dev/null 2>&1 & disown;
    winpty php -S localhost:80 -t ../jobs-platform/public > /dev/null 2>&1 & disown;
    winpty php -S localhost:80 -t ../jobs-platform/public > /dev/null 2>&1 & disown;
    winpty php -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & disown;
    winpty php -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & disown;
    winpty php -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & disown;
    winpty php -S localhost:80 -t ../jobs-platform/public > ../jobs-platform.out 2>&1 & disown;
    php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 & disown;
    php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 & disown;
    php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 & disown;
    php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 & disown;
    winpty php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 & disown;
    winpty php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 & disown;
    winpty php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 & disown;
    winpty php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 & disown;
    taskkill -f -t -im php.exe -im winpty.exe
    winpty php -S localhost:80 -t ../jobs-platform/public & disown;
    winpty php artisan serve --port=8000 & disown;
    tasklist -fi 'imagename eq php*'
    winpty php -S localhost:80 -t ../jobs-platform/public & disown;
    winpty php -S localhost:80 -t $(dirname $PWD)/jobs-platform/public
    "
    echo;
}

MiscDev(){
    git restore public/mix-manifest*;
    find . -name \*.php-tmp -type f -print -delete && rm -rf .phpintel;
}

LaravelLumenStartDev(){
    git restore public/mix-manifest*;
    find . -name \*.php-tmp -type f -print -delete && rm -rf .phpintel;
    ProjFldr=`dirname $PWD` && ProjDir=`dirname $PWD` && ProjRoot=`dirname $PWD`;
    rm -f storage/logs/*.log 2> /dev/null && taskkill -f -t -im 'php*' && rm -f ../*.out 2> /dev/null;
    SyncBranchesPackages;
    composer clear-cache && composer dump-autoload && composer dump-autoload -o;
    rm -fr bootstrap/cache/* && rm -fr storage/framework/cache/* && php artisan clear-compiled;
    php artisan cache:clear && php artisan view:cache && php artisan config:cache;
    php artisan event:cache && php artisan route:cache && php artisan optimize;
    nohup php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 & disown;
    cd ../jobs-platform && SweepFolders && ResetUpdateCodebase;
    SyncBranchesPackages;
    if [[ $(awk -F "=" '/APP_PORT/ {print $2}' .env) ]]; then
        jp_port=$(awk -F "=" '/APP_PORT/ {print $2}' .env)
    else
        jp_port=80
    fi;
    echo "jp_port:$jp_port";
    php.exe -S 127.0.0.1:$jp_port -t ./public > ../jobs-platform.out 2>&1 & disown;
    cd ../jobs-client-ui && history -wc && history -cw;
}
LaravelLumenStartDev-1(){
    git restore public/mix-manifest*;
    find . -name \*.php-tmp -type f -print -delete && rm -rf .phpintel;
    ProjFldr=`dirname $PWD` && ProjDir=`dirname $PWD` && ProjRoot=`dirname $PWD`;
    rm -f storage/logs/*.log 2> /dev/null && taskkill -f -t -im 'php*' && rm -f ../*.out 2> /dev/null;
    SyncBranchesPackages;
    composer clear-cache && composer dump-autoload && composer dump-autoload -o;
    rm -fr bootstrap/cache/* && rm -fr storage/framework/cache/* && php artisan clear-compiled;
    php artisan cache:clear && php artisan view:cache && php artisan config:cache;
    php artisan event:cache && php artisan route:cache && php artisan optimize;
    nohup php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 & disown;
    cd ../jobs-platform && SweepFolders && ResetUpdateCodebase;
    SyncBranchesPackages;
    if [[ $(awk -F "=" '/APP_PORT/ {print $2}' .env) ]]; then
        jp_port=$(awk -F "=" '/APP_PORT/ {print $2}' .env)
    else
        jp_port=80
    fi;
    echo "jp_port:$jp_port";
    php.exe -S 127.0.0.1:$jp_port -t ./public > ../jobs-platform.out 2>&1 & disown;
    cd ../jobs-client-ui && history -wc && history -cw;
}
LaravelLumenStartDev_1(){
    git restore public/mix-manifest*;
    find . -name \*.php-tmp -type f -print -delete && rm -rf .phpintel;
    ProjFldr=`dirname $PWD` && ProjDir=`dirname $PWD` && ProjRoot=`dirname $PWD`;
    rm -f storage/logs/*.log 2> /dev/null && taskkill -f -t -im 'php*' && rm -f ../*.out 2> /dev/null;
    SyncBranchesPackages;
    composer clear-cache && composer dump-autoload && composer dump-autoload -o;
    rm -fr bootstrap/cache/* && rm -fr storage/framework/cache/* && php artisan clear-compiled;
    php artisan cache:clear && php artisan view:cache && php artisan config:cache;
    php artisan event:cache && php artisan route:cache && php artisan optimize;
    nohup php artisan serve --port=8000 > ../jobs-client-ui.out 2>&1 & disown;
    cd ../jobs-platform && SweepFolders && ResetUpdateCodebase;
    SyncBranchesPackages;
    if [[ $(awk -F "=" '/APP_PORT/ {print $2}' .env) ]]; then
        jp_port=$(awk -F "=" '/APP_PORT/ {print $2}' .env)
    else
        jp_port=80
    fi;
    echo "jp_port:$jp_port";
    php.exe -S 127.0.0.1:$jp_port -t ./public > ../jobs-platform.out 2>&1 & disown;
    cd ../jobs-client-ui && history -wc && history -cw;
}

alias strt-vpn='OpenVPNStartDev' && alias strt-lrvl-lmn='LaravelLumenStartDev';
alias strt-node='NodeNPMStartDev' && alias ss-run-2dev='LaravelLumenStartDev';
alias ss-run-3dev='LaravelLumenStartDev && NodeNPMStartDev';
alias ss-run-all-dev='OpenVPNStartDev && LaravelLumenStartDev && NodeNPMStartDev';
alias ss-run-4dev='OpenVPNStartDev && LaravelLumenStartDev && NodeNPMStartDev';
alias syn-brchs-pkgs='SyncBranchesPackages' && alias upd-brchs-pkgs='SyncBranchesPackages';

OpenVPNStartDev(){
    OvpnDir=$HOME/OpenVPN/config;
    PFDir=`cygpath "$PROGRAMFILES"`;
    OpenVPNSvc=OpenVPNServiceInteractive;
    OvpnFile=$OvpnDir/Digital_Services2020/Digital_Services2020.ovpn;
    cbl && net stop $OpenVPNSvc && sc stop $OpenVPNSvc && taskkill -f -t -im openvpn*;
    net start $OpenVPNSvc && nohup "$PFDir/OpenVPN/bin/openvpn.exe" --config $OvpnFile > ../openvpn-rr.out & start `dirname $OvpnFile` & disown;
}
OpenVPNStartTest(){
    OvpnDir=$HOME/OpenVPN/config;
    PFDir=`cygpath "$PROGRAMFILES"`;
    OpenVPNSvc=OpenVPNServiceInteractive;
    OvpnFile=$OvpnDir/Digital_Services2020/Digital_Services2020.ovpn;
    cbl && net stop $OpenVPNSvc && sc stop $OpenVPNSvc && taskkill -f -t -im openvpn*;
    net start $OpenVPNSvc && nohup "$PFDir/OpenVPN/bin/openvpn.exe" --config $OvpnFile > ../openvpn-rr.out & disown;
}
OpenVPNStartProd(){
    OvpnDir=$HOME/OpenVPN/config;
    PFDir=`cygpath "$PROGRAMFILES"`;
    OpenVPNSvc=OpenVPNServiceInteractive;
    OvpnFile=$OvpnDir/Digital_Services2020/Digital_Services2020.ovpn;
    cbl && net stop $OpenVPNSvc && sc stop $OpenVPNSvc && taskkill -f -t -im openvpn*;
    net start $OpenVPNSvc && nohup "$PFDir/OpenVPN/bin/openvpn.exe" --config $OvpnFile > ../openvpn-rr.out & disown;
}

SyncBranchesPackages(){
    read -n 1 -p "Sync Branches & Packages? " ch;
    if [[ $ch =~ ^[Yy]$ ]]; then
        CuBr=`git branch --show-current` && git fetch --all -p;
        git checkout master && git pull && git pull origin;
        git checkout develop && git pull && git pull origin;
        git checkout $CuBr && git pull && git pull origin;
        if [ -f ./composer.json ] && [ -d ./vendor ]; then
            rm -rf vendor/ && rm -f composer.lock && composer clearcache && composer cc && composer install && composer dumpautoload -o && composer du -o;
        fi;
        if [ -f ./package.json ] && [ -d ./node_modules ]; then
            rm -rf node_modules/ && rm -f package-lock.json && npm cache clean -f && npm install && npm audit fix && npm run dev;
            # rm -rf node_modules/ && rm -f package-lock.json && npm cache clean -f && npm install && npm audit fix && npm run watch;
        fi;
    fi;
}
ResetBranchesPackages(){
    read -n 1 -p "Reset Branches & Packages? " ch;
    if [[ $ch =~ ^[Yy]$ ]]; then
        CuBr=`git branch --show-current` && git fetch --all -p;
        git checkout master && git pull && git pull origin;
        git checkout develop && git pull && git pull origin;
        git checkout $CuBr && git pull && git pull origin;
        if [ -f ./composer.json ] && [ -d ./vendor ]; then
            rm -rf vendor/ && rm -f composer.lock && composer clearcache && composer cc && composer install && composer dumpautoload -o && composer du -o;
        fi;
        if [ -f ./package.json ] && [ -d ./node_modules ]; then
            rm -rf node_modules/ && rm -f package-lock.json && npm cache clean -f && npm install && npm audit fix && npm run dev;
            # rm -rf node_modules/ && rm -f package-lock.json && npm cache clean -f && npm install && npm audit fix && npm run watch;
        fi;
    fi;
}
UpdateBranchesPackages(){
    read -n 1 -p "Update Branches & Packages? " ch;
    if [[ $ch =~ ^[Yy]$ ]]; then
        CuBr=`git branch --show-current` && git fetch --all -p;
        git checkout master && git pull && git pull origin;
        git checkout develop && git pull && git pull origin;
        git checkout $CuBr && git pull && git pull origin;
        if [ -f ./composer.json ] && [ -d ./vendor ]; then
            rm -rf vendor/ && rm -f composer.lock && composer clearcache && composer cc && composer install && composer dumpautoload -o && composer du -o;
        fi;
        if [ -f ./package.json ] && [ -d ./node_modules ]; then
            rm -rf node_modules/ && rm -f package-lock.json && npm cache clean -f && npm install && npm audit fix && npm run dev;
            # rm -rf node_modules/ && rm -f package-lock.json && npm cache clean -f && npm install && npm audit fix && npm run watch;
        fi;
    fi;
}

NodeNPMStartDev(){
    cbl && npm cache clean -f && rm -rf $LOCALAPPDATA/npm-cache/_cacache && npm run watch;
}
NodeNPMStartTest(){
    cbl && npm cache clean -f && rm -rf $LOCALAPPDATA/npm-cache/_cacache && npm run watch;
}
NodeNPMStartProd(){
    cbl && npm cache clean -f && rm -rf $LOCALAPPDATA/npm-cache/_cacache && npm run watch;
}

LaravelStart() {
    rm -f storage/logs/*.log 2> /dev/null;
    read -p 'Port? [8000]: 'port && port=${port:-8000};
    composer clear-cache && composer dump-autoload && composer dump-autoload -o;
    rm -fr bootstrap/cache/* && rm -fr storage/framework/cache/* && php artisan clear-compiled;
    php artisan cache:clear && php artisan view:cache && php artisan config:cache && php artisan event:cache && php artisan route:cache && php artisan optimize && php artisan serve --port=$port;
}
LaravelStartDone() {
    rm -f storage/logs/*.log 2> /dev/null;
    read -p 'Port? [8000]: 'port && port=${port:-8000};
    composer clear-cache && composer dump-autoload && composer dump-autoload -o;
    rm -fr bootstrap/cache/* && rm -fr storage/framework/cache/* && php artisan clear-compiled;
    php artisan cache:clear && php artisan view:cache && php artisan config:cache && php artisan event:cache && php artisan route:cache && php artisan optimize && php artisan serve --port=$port;
}
LaravelStartFinal() {
    rm -f storage/logs/*.log 2> /dev/null;
    read -p 'Port? [8000]: 'port && port=${port:-8000};
    composer clear-cache && composer dump-autoload && composer dump-autoload -o;
    rm -fr bootstrap/cache/* && rm -fr storage/framework/cache/* && php artisan clear-compiled;
    php artisan cache:clear && php artisan view:cache && php artisan config:cache && php artisan event:cache && php artisan route:cache && php artisan optimize && php artisan serve --port=$port;
}
LaravelStartUsable() {
    rm -f storage/logs/*.log 2> /dev/null;
    read -p 'Port? [8000]: 'port && port=${port:-8000};
    composer clear-cache && composer dump-autoload && composer dump-autoload -o;
    rm -fr bootstrap/cache/* && rm -fr storage/framework/cache/* && php artisan clear-compiled;
    php artisan cache:clear && php artisan view:cache && php artisan config:cache && php artisan event:cache && php artisan route:cache && php artisan optimize && php artisan serve --port=$port;
}

SweepFolders()
{
    rm -f storage/logs/*.log 2> /dev/null;
    rm -fr storage/logs/* && rm -fr bootstrap/cache/* && rm -fr storage/framework/cache/*\
     && rm -fr storage/framework/sessions/* && composer clear-cache && composer dump-autoload\
     && composer dump-autoload -o;
}
SweepFolders2()
{
    rm -f storage/logs/*.log 2> /dev/null;
    rm -fr storage/logs/* && rm -fr bootstrap/cache/* && rm -fr storage/framework/cache/*\
     && rm -fr storage/framework/sessions/* && composer clear-cache;
}

SweepFoldersOld()
{
    ls -l storage/logs/*.log >/dev/null 2>/dev/null && rm -f storage/logs/*.log;
    rm -fr storage/logs/* && rm -fr bootstrap/cache/* && rm -fr storage/framework/cache/*\
     && rm -fr storage/framework/sessions/* && composer clear-cache && composer dump-autoload\
     && composer dump-autoload -o;
}

PushMods()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    CurBrch=`git symbolic-ref --short HEAD`;
    git diff > ${CurBrch^^}_`date +%F_%T`.patch;
    # git diff --staged > ${CurBrch^^}_`date +%F_%T`.patch;
    read -p "Commit Message: " CommitMsg
    git status && git commit -am "${CurBrch^^}:${CommitMsg}" && git push origin HEAD;
    # git qa;
}

PushModsNwFls()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    { for next in `git ls-files --others --exclude-standard`; \
    do git --no-pager diff --no-index /dev/null $next; done & git diff HEAD --binary; } \
    > `git branch --show-current`_`date +%F_%T`.patch;
    CurBrch=`git symbolic-ref --short HEAD` && read -p "Commit Message: " CommitMsg;
    git add \*.js \*.css \*.vue \*.php && git commit -m "${CurBrch^^}:${CommitMsg}"\
    && git push origin HEAD;
}

PushModsFinalv2()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    git fetch --all -p && CurBrch=`git symbolic-ref --short HEAD`;
    git diff > ${CurBrch^^}_`date +%F_%T`.patch && read -p "Commit Message: " CommitMsg;
    # if [[ $(git branch -a | grep remote/origin/$CurBrch | head -c1 | wc -c) -ne 0 ]]; then
    if [[ $(git branch -r | grep $CurBrch | head -c1 | wc -c) -ne 0 ]]; then
        git status && git commit -am "${CurBrch^^}:${CommitMsg}" && git push origin HEAD;
    else
        git status && git commit -am "${CurBrch^^}:${CommitMsg}" && git push -u origin $CurBrch;
    fi
}

PushModsFinalv3()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    git fetch --all -p && CurBrch=`git symbolic-ref --short HEAD`;
    git diff > ${CurBrch^^}_`date +%F_%T`.patch && read -p "Commit Message: " CommitMsg;
    # if [[ $(git branch -a | grep remote/origin/$CurBrch | head -c1 | wc -c) -ne 0 ]]; then
    if [[ $(git branch -r | grep $CurBrch | head -c1 | wc -c) -ne 0 ]]; then
        git status && git commit -am "${CurBrch^^}:${CommitMsg}" && git push origin HEAD;
    else
        git status && git commit -am "${CurBrch^^}:${CommitMsg}" && git push -u origin $CurBrch;
    fi
}

PushModsFinalv4()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    # if [[ "`git symbolic-ref --short HEAD`" == *\\* ]]; then
    CurBrch=`git symbolic-ref --short HEAD`;
    if [[ "`git symbolic-ref --short HEAD`" == *\/* ]]; then
        CurBrchLbl=`git symbolic-ref --short HEAD | cut -d\/ -f1 | tr '[a-z]' '[A-Z]'`;
    else
        CurBrchLbl=`git symbolic-ref --short HEAD | tr '[a-z]' '[A-Z]'`;
    fi;
    git diff > ${CurBrchLbl^^}_`date +%F_%T`.patch && read -p "Commit Message: " CommitMsg;
    if [[ $(git branch -r | grep $CurBrch | head -c1 | wc -c) -ne 0 ]]; then
        git status && git commit -am "${CurBrchLbl^^}:${CommitMsg}" && git push origin HEAD;
    else
        git status && git commit -am "${CurBrchLbl^^}:${CommitMsg}" && git push -u origin $CurBrch;
    fi;
}

PushModsStgdFinal()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    [[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k && CurBrch=`git symbolic-ref --short HEAD`;
    git clean -df && git checkout -- . && git status;
    if [[ "`git symbolic-ref --short HEAD`" == *\/* ]]; then
        CurBrchLbl=`git symbolic-ref --short HEAD | cut -d\/ -f1 | tr '[a-z]' '[A-Z]'`;
    else
        CurBrchLbl=`git symbolic-ref --short HEAD | tr '[a-z]' '[A-Z]'`;
    fi;
    git diff --staged > ${CurBrchLbl^^}_`date +%F_%T`.patch && read -p "Commit Message: " CommitMsg;
    DscrdLockFileStgdMods && ChoiceOfAddingFiles;
    if [[ $(git branch -r | grep "$CurBrch" | head -c1 | wc -c) -ne 0 ]]; then
        git status && git commit -am "${CurBrchLbl^^}:${CommitMsg}" && git push origin HEAD;
    else
        git status && git commit -am "${CurBrchLbl^^}:${CommitMsg}" && git push -u origin $CurBrch;
    fi;
}

PushModsUnstgdFinal()
{
    # git diff -- ':!*lock*'
    # git diff -- . ':!*lock*'
    # git diff --name-only -- . ':!*lock*'
    # git diff --name-only -- . ':!*lock*' | tr '\n' ' ';
    # git add `git diff --name-only -- . ':!*lock*' | tr '\n' ' '`;
    BtchPrgHstry-v1 && SshPassValid && CurBrch=`git symbolic-ref --short HEAD`;
    if [[ "`git symbolic-ref --short HEAD`" == *\/* ]]; then
        CurBrchLbl=`git symbolic-ref --short HEAD | cut -d\/ -f1 | tr '[a-z]' '[A-Z]'`;
    else
        CurBrchLbl=`git symbolic-ref --short HEAD | tr '[a-z]' '[A-Z]'`;
    fi;
    # git diff > ${CurBrchLbl^^}_`date +%F_%T`.patch && read -p "Commit Message: " CommitMsg;
    git diff -- ':!*.lock' ':!*.json' > ${CurBrchLbl^^}_`date +%F_%T`.patch && \
    read -p "Commit Message: " CommitMsg;
    DscrdLockFileUnstgdMods && ChoiceOfAddingFiles;
    if [[ $(git branch -r | grep "$CurBrch" | head -c1 | wc -c) -ne 0 ]]; then
        git status && git commit -am "${CurBrchLbl^^}:${CommitMsg}" && git push origin HEAD;
    else
        git status && git commit -am "${CurBrchLbl^^}:${CommitMsg}" && git push -u origin $CurBrch;
    fi;
    read -r -p "Merge to \"develop\" branch ? [y/N]" response && [[ "${response,,}" =~ ^(yes|y)$ ]] && \
    (git checkout develop && git merge $CurBrch && git push origin HEAD);
    mv ./*.patch /e/WbmLrvlLrngs/IssueSolutionsCodes
    # mv ./${CurBrchLbl^^}*.patch /e/WbmLrvlLrngs/IssueSolutionsCodes;
}

ChoiceOfAddingFiles() {
    # git rm --cache *.patch && git commit -am 'Remove unrequired .patch files' && git push origin HEAD;
    [[ $(git status -s | grep ?? | cut -d' ' -f2) ]] && read -e -p 'Add files?[Y/n] ' Ch;
    [[ $Ch == 'y' || $Ch == 'Y' ]] && git add -- . ':!*.patch';
}

PushModsUnstgdFinalv0()
{
    # git diff -- ':!*lock*'
    # git diff -- . ':!*lock*'
    # git diff --name-only -- . ':!*lock*'
    # git diff --name-only -- . ':!*lock*' | tr '\n' ' ';
    # git add `git diff --name-only -- . ':!*lock*' | tr '\n' ' '`;
    BtchPrgHstry-v1 && SshPassValid && CurBrch=`git symbolic-ref --short HEAD`;
    if [[ "`git symbolic-ref --short HEAD`" == *\/* ]]; then
        CurBrchLbl=`git symbolic-ref --short HEAD | cut -d\/ -f1 | tr '[a-z]' '[A-Z]'`;
    else
        CurBrchLbl=`git symbolic-ref --short HEAD | tr '[a-z]' '[A-Z]'`;
    fi;
    # git diff > ${CurBrchLbl^^}_`date +%F_%T`.patch && read -p "Commit Message: " CommitMsg;
    git diff -- ':!*lock*' > ${CurBrchLbl^^}_`date +%F_%T`.patch && read -p "Commit Message: " CommitMsg;
    DscrdLockFileUnstgdMods;
    if [[ $(git branch -r | grep "$CurBrch" | head -c1 | wc -c) -ne 0 ]]; then
        git status && git commit -am "${CurBrchLbl^^}:${CommitMsg}" && git push origin HEAD;
    else
        git status && git commit -am "${CurBrchLbl^^}:${CommitMsg}" && git push -u origin $CurBrch;
    fi;
    read -r -p "Merge to \"develop\" branch ? [y/N]" response && [[ "${response,,}" =~ ^(yes|y)$ ]] && \
    (git checkout develop && git merge $CurBrch && git push origin HEAD);
    mv ./${CurBrchLbl^^}*.patch /e/WbmLrvlLrngs/IssueSolutionCodes;
}

PushModsUnstgdFinalv1()
{
    # git diff -- ':!*lock*'
    # git diff -- . ':!*lock*'
    # git diff --name-only -- . ':!*lock*'
    # git diff --name-only -- . ':!*lock*' | tr '\n' ' ';
    # git add `git diff --name-only -- . ':!*lock*' | tr '\n' ' '`;
    BtchPrgHstry-v1 && SshPassValid && CurBrch=`git symbolic-ref --short HEAD`;
    if [[ "`git symbolic-ref --short HEAD`" == *\/* ]]; then
        CurBrchLbl=`git symbolic-ref --short HEAD | cut -d\/ -f1 | tr '[a-z]' '[A-Z]'`;
    else
        CurBrchLbl=`git symbolic-ref --short HEAD | tr '[a-z]' '[A-Z]'`;
    fi;
    # git diff > ${CurBrchLbl^^}_`date +%F_%T`.patch && read -p "Commit Message: " CommitMsg;
    git diff -- ':!*lock*' > ${CurBrchLbl^^}_`date +%F_%T`.patch && read -p "Commit Message: " CommitMsg;
    DscrdLockFileUnstgdMods;
    if [[ $(git branch -r | grep "$CurBrch" | head -c1 | wc -c) -ne 0 ]]; then
        git status && git commit -am "${CurBrchLbl^^}:${CommitMsg}" && git push origin HEAD;
    else
        git status && git commit -am "${CurBrchLbl^^}:${CommitMsg}" && git push -u origin $CurBrch;
    fi;
    read -r -p "Merge to \"develop\" branch ? [y/N]" response && [[ "${response,,}" =~ ^(yes|y)$ ]] && \
    (git checkout develop && git merge $CurBrch && git push origin HEAD);
    mv ./${CurBrchLbl^^}*.patch /e/WbmLrvlLrngs/IssueSolutionCodes;
}

DscrdLockFileStgdMods()
{
    echo "Discard 'lock' file edits ?"
    select choice in Yes No
    do
        if [ $choice = "Yes" ]; then
            git reset HEAD -- *lock* && git restore *lock*;
        fi && break;
    done && return;
}

DscrdLockFileUnstgdMods()
{
    echo "Discard 'lock' file edits ?"
    select choice in Yes No
    do
        if [ $choice = "Yes" ]; then git restore *lock*; fi && break;
    done && return;
}

PushModsToDev()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    CurBrch=`git symbolic-ref --short HEAD`;
    git diff > ${CurBrch^^}_`date +%F_%T`.patch;
    # git diff --staged > ${CurBrch^^}_`date +%F_%T`.patch;
    read -p "Commit Message: " CommitMsg
    git status && git commit -am "${CurBrch^^}:${CommitMsg}" && git push origin HEAD;
    # git qa;
    git checkout develop && git pull origin && git merge $CurBrch && git push origin HEAD;
}

PushMods2Master()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    CurBrch=`git symbolic-ref --short HEAD`;
    git diff > ${CurBrch^^}_`date +%F_%T`.patch;
    # git diff --staged > ${CurBrch^^}_`date +%F_%T`.patch;
    read -p "Commit Message: " CommitMsg
    git status && git commit -am "${CurBrch^^}:${CommitMsg}" && git push origin HEAD;
    git checkout master && git pull origin && git merge ${CurBrch} && git push origin HEAD;
    # git qa;
}

PushModsFix()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    read -p "Ticket ID: " TicketId
    CurBrch=`git symbolic-ref --short HEAD`;
    git diff > ${CurBrch^^}_`date +%F_%T`.patch;
    read -p "Commit Message: " CommitMsg
    git status && git commit -am "${TicketId}:${CommitMsg}" && git push origin HEAD;
}

PushModsFixWebm()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    read -p "Ticket ID: " TicketId
    CurBrch=`git symbolic-ref --short HEAD`;
    # git diff > ${CurBrch^^}_`date +%F_%T`.patch;
    read -p "Commit Message: " CommitMsg
    git status && git commit -am "${TicketId}:${CommitMsg}" && git push origin HEAD;
    git checkout Webmatrix-Deployment && git pull origin && git merge $CurBrch && git push origin HEAD;
    # git qa;
}

PushModsFixDev()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    read -p "Ticket ID: " TicketId
    CurBrch=`git symbolic-ref --short HEAD`;
    # git diff > ${CurBrch^^}_`date +%F_%T`.patch;
    read -p "Commit Message: " CommitMsg
    git status && git commit -am "${TicketId}:${CommitMsg}" && git push origin HEAD;
    git checkout develop && git pull origin && git merge $CurBrch && git push origin HEAD;
    # git qa;
}

PushModsFixAny()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    read -p "Ticket ID: " TicketId
    read -p "Parent Branch ID: " PrntBnch
    CurBrch=`git symbolic-ref --short HEAD`;
    # git diff > ${CurBrch^^}_`date +%F_%T`.patch;
    read -p "Commit Message: " CommitMsg
    git status && git commit -am "${TicketId}:${CommitMsg}" && git push origin HEAD;
    git checkout $PrntBnch && git pull origin && git merge $CurBrch && git push origin HEAD;
    # git qa;
}

PushModsFixGnrc()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    read -p "Ticket ID: " TicketId
    read -p "Parent Branch ID: " PrntBnch
    CurBrch=`git symbolic-ref --short HEAD`;
    # git diff > ${CurBrch^^}_`date +%F_%T`.patch;
    read -p "Commit Message: " CommitMsg
    git status && git commit -am "${TicketId}:${CommitMsg}" && git push origin HEAD;
    git checkout $PrntBnch && git pull origin && git merge $CurBrch && git push origin HEAD;
    # git qa;
}

ClearHistory()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    if [ "$(git rev-parse --git-dir)" == ".git" ]; then
        git restore public/mix-manifest* && git restore public/mix-manifest*;
        git status && read -r -p 'Do extra tasks? ' -n1 ans && [[ "${ans,,}" =~ ^(no|n)$ ]] && return;
        [[ `git diff --name-only` ]] && Unstaged=`git diff --name-only --cached | tr '\n' ' '`;
        [[ `git diff --name-only --cached` ]] && Staged=`git diff --name-only --cached | tr '\n' ' '`;
        read -r -p "Add Unstaged edits ? [y/N] " choice && [[ "${choice,,}" =~ ^(yes|y)$ ]] && git add .;
        read -r -p "Open Staged files ? [y/N] " choice && [[ "${choice,,}" =~ ^(yes|y)$ ]] && subl $Staged;
        read -r -p "Open Unstaged files ? [y/N] " choice && [[ "${choice,,}" =~ ^(yes|y)$ ]] && subl $Unstaged;
        [[ `git status --porcelain | tr -d "M "` =~ "public/mix-manifest.json" ]] && git restore public/mix-manifest.json;
    fi;
}
ClearHistory-v1()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    if [ "$(git rev-parse --git-dir)" == ".git" ]; then
        git restore public/mix-manifest* && git restore public/mix-manifest*;
        git status && read -r -p 'Do extra tasks? ' -n1 ans && [[ "${ans,,}" =~ ^(no|n)$ ]] && return;
        [[ `git diff --name-only` ]] && Unstaged=`git diff --name-only --cached | tr '\n' ' '`;
        [[ `git diff --name-only --cached` ]] && Staged=`git diff --name-only --cached | tr '\n' ' '`;
        read -r -p "Add Unstaged edits ? [y/N] " choice && [[ "${choice,,}" =~ ^(yes|y)$ ]] && git add .;
        read -r -p "Open Staged files ? [y/N] " choice && [[ "${choice,,}" =~ ^(yes|y)$ ]] && subl $Staged;
        read -r -p "Open Unstaged files ? [y/N] " choice && [[ "${choice,,}" =~ ^(yes|y)$ ]] && subl $Unstaged;
        [[ `git status --porcelain | tr -d "M "` =~ "public/mix-manifest.json" ]] && git restore public/mix-manifest.json;
    fi;
}
ClearHistory_v1()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    if [ "$(git rev-parse --git-dir)" == ".git" ]; then
        git restore public/mix-manifest* && git restore public/mix-manifest*;
        git status && read -r -p 'Do extra tasks? ' -n1 ans && [[ "${ans,,}" =~ ^(no|n)$ ]] && return;
        [[ `git diff --name-only` ]] && Unstaged=`git diff --name-only --cached | tr '\n' ' '`;
        [[ `git diff --name-only --cached` ]] && Staged=`git diff --name-only --cached | tr '\n' ' '`;
        read -r -p "Add Unstaged edits ? [y/N] " choice && [[ "${choice,,}" =~ ^(yes|y)$ ]] && git add .;
        read -r -p "Open Staged files ? [y/N] " choice && [[ "${choice,,}" =~ ^(yes|y)$ ]] && subl $Staged;
        read -r -p "Open Unstaged files ? [y/N] " choice && [[ "${choice,,}" =~ ^(yes|y)$ ]] && subl $Unstaged;
        [[ `git status --porcelain | tr -d "M "` =~ "public/mix-manifest.json" ]] && git restore public/mix-manifest.json;
    fi;
}

DevMerge()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    FtrBrnch=`git branch --show-current` && GitSetSshCrdsOnc;
    git checkout develop && git pull origin && git merge $FtrBrnch && git push origin HEAD;
}

NewBrchDevUpdt()
{
    git gc --aggressive --prune=all && read -r -p "Branch Name: " Brnch && git fetch --all -p;
    git checkout develop && git pull && git pull origin && git gc --aggressive --prune=all;
    git reflog expire --all --expire=now && git gc --aggressive --prune=all && git fetch --all -p;
    git checkout -b $Brnch && git reflog expire --all --expire=now && git gc --aggressive --prune=all;
}

NewBrchStgUpdt()
{
    git gc --aggressive --prune=all && read -r -p "Branch Name: " Brnch && git fetch --all -p;
    if [[ -z $(git branch --list stage) ]]; then
        git checkout staging && git pull && git pull origin && git gc --aggressive --prune=all;
    else
        git checkout stage && git pull && git pull origin && git gc --aggressive --prune=all;
    fi;
    git reflog expire --all --expire=now && git gc --aggressive --prune=all && git fetch --all -p;
    git checkout -b $Brnch && git reflog expire --all --expire=now && git gc --aggressive --prune=all;
}

NewBrchMstrUpdt()
{
    git gc --aggressive --prune=all && read -r -p "Branch Name: " Brnch && git fetch --all -p;
    git checkout master && git pull && git pull origin && git gc --aggressive --prune=all;
    git reflog expire --all --expire=now && git gc --aggressive --prune=all && git fetch --all -p;
    git checkout -b $Brnch && git reflog expire --all --expire=now && git gc --aggressive --prune=all;
}

MstrMerge()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    FtrBrnch=`git branch --show-current` && GitSetSshCrdsOnc;
    git checkout master && git pull origin && git merge $FtrBrnch && git push origin HEAD;
}

MrgMstrWth()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    FtrBrnch=`git branch --show-current`;CurBrch=`git branch --show-current`;
    git checkout master && git fetch --all -p && git pull && git pull origin;
    git checkout $FtrBrnch && git merge master && git push origin HEAD;
}

PrntMerge()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    FtrBrnch=`git branch --show-current` && GitSetSshCrdsOnc;
    IFS=', ' && while true; do
        read -p "Merge to: [1]:Develop [2]:Master [3]:Both Branches [E]xit: " -a array
        for choice in "${array[@]}"; do
            case "$choice" in
                [1]*) git checkout develop && git pull origin && git merge $FtrBrnch && git push origin HEAD;;
                [2]*) git checkout master && git pull origin && git merge $FtrBrnch && git push origin HEAD;;
                [3]*) git checkout develop && git pull origin && git merge $FtrBrnch && git push origin HEAD;
                       git checkout master && git pull origin && git merge $FtrBrnch && git push origin HEAD;;
                [Ee]*) echo "exited by user"; exit;;
                *) echo "Wrong choice, kindly check menu again...";;
            esac
        done
    done
}

UpdtCmpsrDpns()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    composer --version && composer self-update && composer clear-cache && rm composer.lock;
    COMPOSER_MEMORY_LIMIT=-1 composer install && composer dumpautoload -o;
}

BackupBashExec()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    CurPth=`pwd` && echo $CurPth;
    [ "$pwd" != "/c/network-sites" ] && cd "/c/network-sites";
    cp .git/config GitConfig_`date +%F`.gitconfig && cp Exec.sh{,_`date +%F`.sh}
    cp .git/config GitConfig_`date +%F_%T`.gitconfig && cp Exec.sh{,_`date +%F_%T`.sh}
    cp .gitaliases GitAliases_`date +%F`.gitaliases && cp .gitaliases GitAliases_`date +%F_%T`.gitaliases
}

BackupBashExecAll()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    CurPth2=`pwd` && CurPth=`pwd`/ExctBshScrpts_`date +%F_%T` && mkdir $CurPth;
    cd $CurPth && mkdir LeadMatchTool && cd "/c/lmt2";
    cp Exec.sh $CurPth/LeadMatchTool/Exec.sh;
    cp .git/config $CurPth/LeadMatchTool/GitConfig.gitconfig;
    cp .gitattributes $CurPth/LeadMatchTool/GitAttributes.gitattributes;
    cd $CurPth && mkdir NetworkSites && cd "/c/network-sites";
    cp Exec.sh $CurPth/NetworkSites/Exec.sh;
    cp .git/config $CurPth/NetworkSites/GitConfig.gitconfig;
    cp .gitaliases $CurPth/NetworkSites/GitAliases.gitaliases;
    cd $CurPth && mkdir GatheringSites && cd "/c/gathering-sites-2";
    cp Exec.sh $CurPth/GatheringSites/Exec.sh;
    cp .git/config $CurPth/GatheringSites/GitConfig.gitconfig;
    cp .gitaliases $CurPth/GatheringSites/GitAliases.gitaliases;
    cd $CurPth && mkdir JobsClientUI && cd "/c/jobs-client-ui";
    cp Exec.sh $CurPth/JobsClientUI/Exec.sh;
    cp .git/config $CurPth/JobsClientUI/GitConfig.gitconfig;
    cd $CurPth && mkdir JobsPlatform && cd "/c/jobs-platform";
    cp Exec.sh $CurPth/JobsPlatform/Exec.sh;
    cp .git/config $CurPth/JobsPlatform/GitConfig.gitconfig;
    cd $CurPth && mkdir FBMapping && cd "/c/facebook-mapping";
    cp Exec.sh $CurPth/FBMapping/Exec.sh;
    cp .git/config $CurPth/FBMapping/GitConfig.gitconfig;
    cp .gitaliases $CurPth/FBMapping/GitAliases.gitaliases;
    cd $CurPth && mkdir RrSsoLaravel && cd "/c/rr-sso-laravel";
    cp Exec.sh $CurPth/RrSsoLaravel/Exec.sh;
    cp .git/config $CurPth/RrSsoLaravel/GitConfig.gitconfig;
    cp .gitaliases $CurPth/RrSsoLaravel/GitAliases.gitaliases;
    cd $CurPth && mkdir Wordpress && cd "/c/xampp/htdocs/wordpress55";
    cp WPExec.sh $CurPth/Wordpress/WPExec.sh;
    cp WPBashExec.sh $CurPth/Wordpress/WPBashExec.sh;
    cp WPBashScripts.sh $CurPth/Wordpress/WPBashScripts.sh;
    cd $CurPth && mkdir UserHome && cd $HOME;
    cp .bashrc $CurPth/UserHome/.bashrc;
    cp .gitconfig $CurPth/UserHome/.gitconfig;
    cp .bash_profile $CurPth/UserHome/.bash_profile;
    cd $CurPth2;
}

UpdtCmpsrSftwr()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    composer --version && composer self-update && composer clear-cache;
    COMPOSER_MEMORY_LIMIT=-1 composer dump-autoload && composer dumpautoload -o;
}

PackRepoAllItemsNS()
{
    NowDateTime=`date +"%Y-%m-%d_%I_%M_%p"`;
    [ "$pwd" != "/c/network-sites" ] && cd "/c/network-sites";
    git archive | tar --exclude='./vendor' --exclude='./node_modules' -zcvf NetworkSites_$NowDateTime.tgz .;
}

PackRepoAllItemsGS()
{
    NowDateTime=`date +"%Y-%m-%d_%I_%M_%p"`;
    [ "$pwd" != "/c/gathering-sites-2" ] && cd "/c/gathering-sites-2";
    git archive | tar --exclude='./vendor' --exclude='./node_modules' -zcvf GatheringSites_$NowDateTime.tgz .;
}

UpdtPrntBrnchsFrmRmt()
{
    git-ssh-auth && git fetch --all -p;
    (git checkout develop && git pull origin) || (git checkout master && git pull origin);
}

UpdtPrntBrnchsFrmRmtv1()
{
    git-ssh-auth && git fetch --all -p;
    (git checkout develop && git pull origin && git checkout master && git pull origin && \
        git checkout develop) || (git checkout master && git pull origin);
}

UpdtPrntBrnchsFrmRmtFinal()
{
    git-ssh-auth && git fetch --all -p;
    (git checkout develop && git pull origin && git checkout master && git pull origin && \
        git checkout develop) || (git checkout master && git pull origin);
}

UpdtPrntBrnchsFrmRmtFinalv1()
{
    git-ssh-auth && git fetch --all -p;
    (git checkout master && git pull origin && git checkout develop && git pull origin) \
     || (git checkout master && git pull origin);
}

isGitBranchValid()
{
    local branch=$1
    [[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k;
    local l1=$(git branch --list ${branch,,})
    local l2=$(git branch --list ${branch^^})
    local r1=$(git ls-remote --heads origin ${branch,,})
    local r2=$(git ls-remote --heads origin ${branch^^})
    if [ -z $l1 ] && [ -z $r1 ]; then lcNotExist=1; fi;
    if [ -z $l2 ] && [ -z $r2 ]; then ucNotExist=1; fi;
    if [ $lcNotExist = 1 ] && [ $ucNotExist = 1 ]; then echo 0 && return; fi;
    echo 1 && return;
}

isGitBranchValidv1()
{
    # local branch=$1
    local in_local=$(git branch -a | grep -i $1);
    local in_remote=$(git branch --list | grep -i $1);
    [ $in_local ] && echo $in_local; [ $in_remote ] && echo $in_remote;
    [[ $in_local || $in_remote ]] && echo Yes && return; echo No && return;
    # [[ $in_local || $in_remote ]] && echo 1 && return; echo 0 && return;
}

isGitBranchValidDone()
{
    local in_local=$(git branch -a | grep -i $1);
    local in_remote=$(git branch --list | grep -i $1);
    [ $in_local ] && echo $in_local; [ $in_remote ] && echo $in_remote;
    [[ $in_local || $in_remote ]] && echo Yes && return; echo No && return;
}

isGitBranchValidFinal()
{
    local in_local=$(git branch -a | grep -i $1);
    local in_remote=$(git branch --list | grep -i $1);
    [ $in_local ] && echo $in_local; [ $in_remote ] && echo $in_remote;
    [[ $in_local || $in_remote ]] && echo Yes && return; echo No && return;
}

RunArtisanWithNode()
{
    # "C:\Program Files\Git\usr\bin\bash.exe" -lic 'pwd'
    # "C:\Program Files\Git\usr\bin\bash.exe" -l -i -c 'pwd'
    "C:\Program Files\Git\usr\bin\bash.exe" -lic 'npm run watch-poll';
    "C:\Program Files\Git\usr\bin\bash.exe" -lic 'sa';
}

CrtFrshBrnchFrmDvlp()
{
    read -p "Branch Name/ID: " Brnch;
    git-ssh-auth && git fetch --all -p;
    (git checkout develop && git pull origin) || (git checkout master && git pull origin);
    git checkout -b ${Brnch,,}
}

GitCrtBrnchPtchDone()
{
    InGitRepo=`git rev-parse --is-inside-work-tree`;
    [ "$InGitRepo" != "true" ] && printf "Not in Git Repo" && return 0;
    echo -n "Parent Branch ?" && read PrntBrnch && NowDateTime=`date +"%Y-%m-%d_%I_%M_%p"`;
    PrsntBrnch=`git symbolic-ref --short HEAD` && MrgngBrnch=`git merge-base --fork-point $PrntBrnch`;
    # git format-patch $MrgngBrnch..$PrsntBrnch --stdout > ${PrsntBrnch^^}_$NowDateTime.patch;
    git format-patch $MrgngBrnch..$PrsntBrnch ':!*.lock' ':!*.svg' --stdout > ${PrsntBrnch^^}_$NowDateTime.patch;
}

GitCrtRptyBndlDone()
{
    InGitRepo=`git rev-parse --is-inside-work-tree`;
    [ "$InGitRepo" != "true" ] && printf "Not in Git Repo" && return 0;
    # git-ssh-auth && git fetch --all -p;
    SshPassValidv2 && git fetch --all -p && git pull origin;
    NowDateTime=`date +"%Y-%m-%d_%I_%M_%p"` && git bundle create ${RepoId}_$NowDateTime.bundle --all
    (git checkout develop || git checkout master) && git pull origin;
    RepoUrl=`git config --get remote.origin.url` && [[ "$RepoUrl" =~ /([^./]+)\. ]] && RepoId="${BASH_REMATCH[1]}";
    CurrDateTime=`date +"%Y-%m-%d_%I_%M_%p"` && git bundle create ${RepoId}_$CurrDateTime.bundle --all
}

GitCrtRptyBndlFinalv1()
{
    InGitRepo=`git rev-parse --is-inside-work-tree`;
    [ "$InGitRepo" != "true" ] && printf "Not in Git Repo" && return 0;
    RepoUrl=`git config --get remote.origin.url` && [[ "$RepoUrl" =~ /([^./]+)\. ]] && RepoId="${BASH_REMATCH[1]}";
    SshPassValidv2 && git fetch --all -p && git pull origin;
    NowDateTime=`date +"%Y-%m-%d_%I_%M_%p"` && git bundle create ${RepoId}_$NowDateTime.bundle --all
    (git checkout develop || git checkout master) && git pull origin;
    CurrDateTime=`date +"%Y-%m-%d_%I_%M_%p"` && git bundle create ${RepoId}_parent_$CurrDateTime.bundle --all
}

GitCrtRptyBndlFinalv2()
{
    InGitRepo=`git rev-parse --is-inside-work-tree`;
    [ "$InGitRepo" != "true" ] && printf "Not in Git Repo" && return 0;
    RepoUrl=`git config --get remote.origin.url` && [[ "$RepoUrl" =~ /([^./]+)\. ]] && RepoId="${BASH_REMATCH[1]}";
    SshPassValidv2 && git fetch --all -p && git pull origin;
    NowDateTime=`date +"%Y-%m-%d_%I_%M_%p"` && git bundle create ${RepoId}_$NowDateTime.bundle --all
    (git checkout develop || git checkout master) && git pull origin;
    CurrDateTime=`date +"%Y-%m-%d_%I_%M_%p"` && git bundle create ${RepoId}_parent_$CurrDateTime.bundle --all
}

VueCrtCmpntDone()
{
    read -p "Component Name: " CmpnNm;
    cat > ./resources/js/components/$CmpnNm.vue <<"EOF"
<template>

</template>

<script>
export default {

}
</script>

<style>

</style>
EOF
subl ./resources/js/components/$CmpnNm.vue;
}

GitUpdtBrnchFrmRmt()
{
    [[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k;
    git fetch --all -p && git pull origin;
}

GitSetSshCrdsOnc()
{
    [[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k;
    git fetch --all -p && git pull origin;
}

AskPassOnceSshAgent()
{
    [[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k;
    git fetch --all -p && git pull origin;
}

GitMkNwBrnhFrmMain()
{
    [[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k;
    echo -n "Branch ? " && read b1 && echo -n "Parent ? " && read b2;
    git checkout $b2 && git fetch --all -p && git fetch --all && git fetch --tags;
    git reflog expire --all --expire=now && git gc --aggressive --prune=all;
    git pull && git pull origin && git checkout -b $b1;
}

GitMkNwBrnhFrmPrnt()
{
    [[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k;
    echo -n "Branch ? " && read b1 && echo -n "Parent ? " && read b2;
    git checkout $b2 && git fetch --all -p && git fetch --all && git fetch --tags;
    git reflog expire --all --expire=now && git gc --aggressive --prune=all;
    git pull && git pull origin && git checkout -b $b1;
}

GitMkNwBrnhFrmSupe()
{
    [[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k;
    echo -n "Branch ? " && read b1 && echo -n "Parent ? " && read b2;
    git checkout $b2 && git fetch --all -p && git fetch --all && git fetch --tags;
    git reflog expire --all --expire=now && git gc --aggressive --prune=all;
    git pull && git pull origin && git checkout -b $b1;
}

GitClnRpryMstrBrnh()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    [[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k;
    echo -n "RepoUrl ? " && read RepoUrl && git clone $RepoUrl;
    git fetch --all && git fetch --all -p && git pull origin;
    composer clear-cache && composer install && composer dump-autoload -o;
    npm cache clean -f && npm install;
}

UpdtCmpsrNpmDpns()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    composer --version && composer self-update && composer clear-cache && rm composer.lock;
    COMPOSER_MEMORY_LIMIT=-1 composer install && composer dumpautoload -o && npm cache clean -f && npm install;
}

InstlCmpsrNpmDpns()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    php composer --version && php composer clear-cache && COMPOSER_MEMORY_LIMIT=-1 php composer install;
    php composer dumpautoload -o && npm cache clean -f && npm install;
}

GitPtchBrnhMdsFinalv1()
{
    CurBrch=`git symbolic-ref --short HEAD`;
    if [[ "`git symbolic-ref --short HEAD`" == *\/* ]]; then
        CurBrchLbl=`git symbolic-ref --short HEAD | cut -d\/ -f1 | tr '[a-z]' '[A-Z]'`;
    else
        CurBrchLbl=`git symbolic-ref --short HEAD | tr '[a-z]' '[A-Z]'`;
    fi;
    git diff -- ':!*.lock' ':!*.json' > ${CurBrchLbl^^}_`date +%F_%T`.patch;
}

NtrSshOtp()
{
    [[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k;
    git fetch --all -p && git fetch origin && git pull origin;
}

# GitClnProjectForErrorFix()
# {
#     declare -a KeepFiles=('.git/config' 'Exec.sh' '.env') && OrigProjName=`basename $(pwd)`;
#     OrigProjDir=`pwd` && RepoName=`basename $(git remote get-url origin) .git`;
#     RepoCloneUrl=`git ls-remote --get-url` && DestProjDir=$(dirname `pwd`)\/${RepoName}_`date +%F`;
#     # find . -type d -empty -print && find . -type d -empty -delete;
#     shopt -s extglob;
#     rm -rf */!(.git/config|Exec.sh|.env) && find . -type d -empty -delete;
#     rm !(.git/config|Exec.sh|.env) && cd .. && git clone $RepoCloneUrl $DestProjDir && cd $DestProjDir;
#     git fetch --all -p && git pull origin && git checkout develop && git pull origin;
#     cd $OrigProjDir && cp --parents .git/info/exclude Exec.sh .env $DestProjDir;
#     # Manually copy the 'alias' section from old .git/config to new one.
#     cd $DestProjDir && rm -rf $OrigProjDir && cd .. && rename $DestProjDir $OrigProjDir;
# }

SshPassValid() { [[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k; }

SshPassValidv1()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    [[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k;
}

SshPassValidv2()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    [[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k;
    git fetch --all -p && git fetch --all -p && git fetch --all -p;
    git reflog expire --all --expire=now && git gc --prune=now --aggressive;
    git reflog expire --all --expire=now && git gc --prune=now --aggressive;
}

SshPassValidv5()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    [[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k;
    git fetch --all -p && git fetch --all -p && git fetch --all -p;
    git reflog expire --all --expire=now && git gc --prune=now --aggressive;
    git reflog expire --all --expire=now && git gc --prune=now --aggressive;
}

SshPassValidv6()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    [[ -z ${SSH_AGENT_PID+x} ]] && eval `ssh-agent -s` && ssh-add -k;
    git fetch --all -p && git fetch --all -p && git fetch --all -p;
    git reflog expire --all --expire=now && git gc --prune=now --aggressive;
    git reflog expire --all --expire=now && git gc --prune=now --aggressive;
}

BtchPrgHstry-v1()
{
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
}

BackupBashExecAllv1(){
    read -p 'Project Folder Path? ' PrjctPth;
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    CurPth2=`pwd` && CurPth=`pwd`/ExctBshScrpts_`date +%F_%T` && mkdir $CurPth;
    RepoDirs=('network-sites' 'gathering-sites-2' 'jobs-client-ui' 'jobs-platform' 'robbot'\
        'facebook-mapping' 'rr-sso-laravel' 'careers-in-gear' 'recruiting-admin' 'lmt2');
    for RepoDir in ${RepoDirs[*]}; do
        cd $CurPth && mkdir $RepoDir && cd "$PrjctPth/${RepoDir}";
        cp .env $CurPth/${RepoDir}/.env;
        cp Exec.sh $CurPth/${RepoDir}/Exec.sh;
        cp .gitignore $CurPth/${RepoDir}/.gitignore;
        cp cypress.json $CurPth/${RepoDir}/cypress.json;
        cp .git/config $CurPth/${RepoDir}/GitConfig.gitconfig;
        cp cypress.env.json $CurPth/${RepoDir}/cypress.env.json;
        cp .gitattributes $CurPth/${RepoDir}/GitAttributes.gitattributes;
    done
    cd $CurPth && mkdir Wordpress && cd "/c/xampp/htdocs/wordpress55";
    cp WPExec.sh $CurPth/Wordpress/WPExec.sh;
    cp WPBashExec.sh $CurPth/Wordpress/WPBashExec.sh;
    cp WPBashScripts.sh $CurPth/Wordpress/WPBashScripts.sh;
    cd $CurPth && mkdir UserHome && cd $HOME;
    cp .bashrc $CurPth/UserHome/.bashrc;
    cp .gitconfig $CurPth/UserHome/.gitconfig;
    cp .bash_profile $CurPth/UserHome/.bash_profile;
    cd $CurPth && mkdir OS-HostsFile && cd $WINDIR;
    cp ./System32/drivers/etc/hosts $CurPth/OS-HostsFile/hosts;
    cd $CurPth2;
}

BackupBashExecAllv2(){
    read -p 'Project Folder Path? ' PrjctPth;
    history -cw && history -wc && reset && clear && rm -f $HISTFILE;
    CurPth2=`pwd` && CurPth=`pwd`/ExctBshScrpts_`date +%F_%T` && mkdir $CurPth;
    RepoDirs=('network-sites' 'gathering-sites-2' 'jobs-client-ui' 'jobs-platform' 'robbot'\
        'facebook-mapping' 'rr-sso-laravel' 'careers-in-gear' 'recruiting-admin' 'lmt2');
    for RepoDir in ${RepoDirs[*]}; do
        cd $CurPth && mkdir $RepoDir && cd "$PrjctPth/${RepoDir}";
        cp .env $CurPth/${RepoDir}/.env;
        cp Exec.sh $CurPth/${RepoDir}/Exec.sh;
        cp .gitignore $CurPth/${RepoDir}/.gitignore;
        cp cypress.json $CurPth/${RepoDir}/cypress.json;
        cp .git/config $CurPth/${RepoDir}/GitConfig.gitconfig;
        cp cypress.env.json $CurPth/${RepoDir}/cypress.env.json;
        cp .gitattributes $CurPth/${RepoDir}/GitAttributes.gitattributes;
    done
    cd $CurPth && mkdir Wordpress && cd "/c/xampp/htdocs/wordpress55";
    cp WPExec.sh $CurPth/Wordpress/WPExec.sh;
    cp WPBashExec.sh $CurPth/Wordpress/WPBashExec.sh;
    cp WPBashScripts.sh $CurPth/Wordpress/WPBashScripts.sh;
    cd $CurPth && mkdir UserHome && cd $HOME;
    cp .bashrc $CurPth/UserHome/.bashrc;
    cp .gitconfig $CurPth/UserHome/.gitconfig;
    cp .bash_profile $CurPth/UserHome/.bash_profile;
    cd $CurPth && mkdir OS-HostsFile && cd $WINDIR;
    cp ./System32/drivers/etc/hosts $CurPth/OS-HostsFile/hosts;
    cd $CurPth2;
}

EditHostsFile() { subl $WINDIR/System32/drivers/etc/hosts; }
OpenHostsFile() { subl $WINDIR/System32/drivers/etc/hosts; }
RstUpdtCmpsrPkgs() { rm -rf vendor/ && rm -f composer.lock && composer clear-cache && composer update && composer dump-autoload; };
RstInstCmpsrPkgs() { rm -rf vendor/ && rm -f composer.lock && composer clear-cache && composer install && composer dump-autoload; };
RstUpdtCmpsrPkgs2()
{
    rm -rf vendor/ && rm -f composer.lock && composer clear-cache && composer update && composer dump-autoload;
    npm cache clean -f && npm install && npm audit fix && npm run dev;
};
RstInstCmpsrPkgs2()
{
    rm -rf vendor/ && rm -f composer.lock && composer clear-cache && composer install && composer dump-autoload;
    npm cache clean -f && npm install && npm audit fix && npm run dev;
};
OnlyNpmInstPkgs() { npm cache clean -f && npm install && npm audit fix && npm run dev; };
OnlyNpmUpdtPkgs() { npm cache clean -f && npm update && npm audit fix && npm run dev; };
CmpsrDmpld() { composer dump-autoload && composer dump-autoload -o; }

: '
git co rde-481 && git co develop && git fetch --all -p && git pull && git pull origin && git merge rde-481 && git push origin HEAD
git co rde-481 && git co develop && git fetch --all -p && git pull && git pull origin && git merge rde-481 && git push origin HEAD
git co rde-481 && git co develop && git fetch --all -p && git pull && git pull origin && git merge rde-481 && git push origin HEAD
git co rde-481 && git co develop && git fetch --all -p && git pull && git pull origin && git merge rde-481 && git push origin HEAD

git co master && git fetch --all -p && git pull && git pull origin && git pull && git pull origin
git co master && git fetch --all -p && git pull && git pull origin && git pull && git pull origin
git co master && git fetch --all -p && git pull && git pull origin && git pull && git pull origin
git co master && git fetch --all -p && git pull && git pull origin && git pull && git pull origin

git co develop && git fetch --all -p && git pull && git pull origin && git pull && git pull origin
git co develop && git fetch --all -p && git pull && git pull origin && git pull && git pull origin
git co develop && git fetch --all -p && git pull && git pull origin && git pull && git pull origin
git co develop && git fetch --all -p && git pull && git pull origin && git pull && git pull origin
'
