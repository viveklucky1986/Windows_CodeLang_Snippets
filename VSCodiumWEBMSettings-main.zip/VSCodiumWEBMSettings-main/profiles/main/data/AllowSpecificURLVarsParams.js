// ==UserScript==
// @name          Clean Google search URL Fair
// @author        Vivek Shah
// @description   Unscrambles urls on Google search
// @homepage      http://sumtips.com/
// @match         *://*.google.com/search*
// @match         *://*.google.nl/search*
// @version       1.4
// ==/UserScript==

function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars[hash[0]] = hash[1];
    }
    return vars;
}

function keepUrlVars(reqVars = []) {
    let url = new URL(location.href);
    for(var key in getUrlVars()) { if(!reqVars.includes(key)) url.searchParams.delete(key); }
    window.history.replaceState({}, null, url);
}

keepUrlVars(['q','tbm']);
history.replaceState({}, document.title, window.location.href.split('#')[0]);
