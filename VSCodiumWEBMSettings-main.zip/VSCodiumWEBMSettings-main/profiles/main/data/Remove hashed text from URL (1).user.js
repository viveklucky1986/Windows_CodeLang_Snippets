// ==UserScript==
// @name          Remove hashed text from URL
// @author        Vivek Shah
// @description   Unscrambles urls on Google search
// @homepage      http://sumtips.com/
// @match         *://*/*
// @version       1.4
// ==/UserScript==
history.replaceState({}, document.title, window.location.href.split('#')[0]);
