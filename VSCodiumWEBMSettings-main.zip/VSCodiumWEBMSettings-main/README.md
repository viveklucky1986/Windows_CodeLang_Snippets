# VSCodiumWEBMSettings
### VSCode/VSCodium settings.json
#### VSCode/VSCodium [Sync Settings](https://marketplace.visualstudio.com/items?itemName=zokugun.sync-settings) Extension URL: https://marketplace.visualstudio.com/items?itemName=zokugun.sync-settings
```json
{
    "editor.fontSize": 15,
    "sync.quietSync": true,
    "sync.autoUpload": true,
    "editor.wordWrap": "on",
    "sync.forceUpload": true,
    "sync.autoDownload": true,
    "sync.forceDownload": true,
    "sync.syncExtensions": true,
    "sync.removeExtensions": true,
    "editor.wrappingIndent": "same",
    "files.trimFinalNewlines": true,
    "files.insertFinalNewline": true,
    "files.trimTrailingWhitespace": true,
    "sync.gist": "0fc26ed1c17e445be6b53f20777fae4a",
    "security.workspace.trust.untrustedFiles": "open",
    "editor.fontFamily": "'Fira Code Retina', Consolas, 'Courier New', monospace",
}
```
```json
{
    "editor.fontSize": 16,
    "sync.quietSync": true,
    "sync.autoUpload": true,
    "editor.wordWrap": "on",
    "sync.forceUpload": true,
    "sync.autoDownload": true,
    "sync.forceDownload": true,
    "sync.syncExtensions": true,
    "sync.removeExtensions": true,
    "editor.wrappingIndent": "same",
    "files.trimFinalNewlines": true,
    "files.insertFinalNewline": true,
    "files.trimTrailingWhitespace": true,
    "sync.gist": "0fc26ed1c17e445be6b53f20777fae4a",
    "security.workspace.trust.untrustedFiles": "open",
    "editor.fontFamily": "'Fira Code Retina', Consolas, 'Courier New', monospace",
    "syncSettings.resources": ["extensions", "keybindings", "settings", "snippets", "uiState"]
}
```
### Sync Settings - Profile Settings:
```yml
# (settings.yml)
profile: main
# sync on remote git
repository:
  type: git
  # url of the remote git repository to sync with, required
  url: https://github.com/vivek1986/VSCodiumWEBMSettings.git
  # branch to sync on, optional (set to `master` by default)
  branch: master
```
